# UCOS — Universal Course Opting System
### v3.1 — Complete Release

---

## What Was Built

UCOS is a full-stack web application for running **PWFCFS-MRA** (Priority Weighted First-Come First-Served with Multi-Round Allocation) elective course opting for colleges.

---

## Architecture

```
ucos-app/
├── backend/                  Node.js + Express + MySQL
│   ├── src/
│   │   ├── controllers/
│   │   │   ├── authController.js       Auth (admin + student OTP)
│   │   │   ├── adminController.js      Students, CSV upload, pending
│   │   │   ├── electionController.js   Election lifecycle
│   │   │   ├── courseController.js     Course CRUD
│   │   │   ├── studentController.js    Dashboard, booking, results
│   │   │   ├── allocationController.js PWFCFS-MRA rounds + export
│   │   │   └── cavController.js        CAV system (join codes + messages)
│   │   ├── routes/index.js             All API routes
│   │   ├── middleware/auth.js          JWT middleware
│   │   └── config/                    DB + email config
│   └── database/
│       ├── schema.sql                  Full schema (13 tables)
│       └── migrate_v3.sql             v2 → v3 migration (3 new tables)
└── frontend/                 React 18
    └── src/
        ├── pages/
        │   ├── admin/
        │   │   ├── Dashboard.js        Animated KPIs + charts
        │   │   ├── ElectionControl.js  Election lifecycle + inline CAV
        │   │   ├── CAVPanel.js         Participant management
        │   │   ├── Courses.js          Course CRUD + demand heatmap
        │   │   ├── AllocationPanel.js  Rounds + unallocated tab
        │   │   ├── Students.js         Student list + CSV
        │   │   ├── Pending.js          Credential cards + filters
        │   │   └── Profile.js          Admin settings
        │   ├── student/
        │   │   ├── Dashboard.js        Seat grid + token pipeline
        │   │   ├── Bookings.js         Token overview
        │   │   ├── Results.js          Final allocation results
        │   │   ├── Participation.js    Join elections via code
        │   │   ├── Messages.js         Expiring notifications
        │   │   └── Profile.js          Student settings
        │   ├── auth/                   Login + Register + OTP
        │   └── JoinElection.js         Public join page (/join/:code)
        └── components/ui/             Sidebar, Charts, UI primitives
```

---

## Setup

### Prerequisites
- Node.js 18+
- MySQL 8+
- SMTP credentials (Gmail App Password recommended)

### 1. Database
```bash
mysql -u root -p < backend/database/schema.sql
# Upgrading from v2? Run only:
mysql -u root -p < backend/database/migrate_v3.sql
```

### 2. Backend
```bash
cd backend
cp .env.example .env   # edit with your credentials
npm install
npm start              # runs on :3001
```

`.env` keys:
```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=ucos_db
JWT_SECRET=your-32-char-secret
JWT_EXPIRES_IN=24h
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=you@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=UCOS <you@gmail.com>
FRONTEND_URL=http://localhost:3000
```

### 3. Frontend
```bash
cd frontend
npm install
npm start              # runs on :3000
```

---

## User Flows

### Admin — Standard Flow
1. Register at `/admin/register` → verify email OTP
2. Create election → CAV code auto-generated
3. Add courses (`/admin/courses`)
4. Upload students CSV (`/admin/students`) **OR** share join code
5. Initialise tokens & seats (checklist on `/admin/election`)
6. Start election → students book courses
7. Stop election → auto-assigns non-participants
8. Run allocation rounds (`/admin/allocation`)
9. Verify → Export CSV → Email students

### Admin — CAV Flow (Optional Participant System)
1. Election created → join code visible on Election Control page
2. Share code or link with external participants
3. Review applicants at `/admin/cav` → Confirm or Reject
4. Confirmed participants linked to election + receive message
5. Election stopped → code expires automatically

### Student — Standard Flow
1. Receive credentials from admin → login at `/login`
2. Dashboard shows token pipeline + interactive seat grid
3. Book courses using tokens (FCFS, atomic, rate-limited)
4. View results at `/student/results` after allocation

### Student — CAV (Participant) Flow
1. Receive join code/link from admin
2. Open `/join/<CODE>` (no login needed to view)
3. Login → enter email for identity verification
4. Admin confirms → receive message notification
5. Update display name at `/student/join` if needed
6. Join election normally

---

## API Reference

### Auth
| Method | Path | Description |
|--------|------|-------------|
| POST | `/auth/admin/register` | Create admin account |
| POST | `/auth/admin/login` | Admin login |
| POST | `/auth/student/register` | Student self-register |
| POST | `/auth/student/login` | Student login |
| POST | `/auth/verify-otp` | Verify email OTP |
| POST | `/auth/resend-otp` | Resend OTP |

### CAV System
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/join/:code` | Public | Resolve code → election info |
| POST | `/cav/apply` | Student | Apply via code |
| PUT | `/cav/name` | Student | Update display name |
| GET | `/cav/participation` | Student | My applications |
| GET | `/cav/messages` | Student | My messages |
| PUT | `/cav/messages/:id/read` | Student | Mark read |
| GET | `/cav/:election_id` | Admin | Get/create CAV |
| POST | `/cav/:election_id/regenerate` | Admin | New code |
| GET | `/cav/:election_id/participants` | Admin | Applicant list |
| POST | `/cav/participants/:id/review` | Admin | Confirm/reject |

### Allocation (Enhanced)
| Method | Path | Description |
|--------|------|-------------|
| GET | `/allocation/:id/pool` | Round data |
| POST | `/allocation/confirm` | Confirm course |
| POST | `/allocation/burst` | Burst course |
| GET | `/allocation/:id/verify` | Verify allocation |
| GET | `/allocation/:id/export` | Download CSV |
| POST | `/allocation/:id/email` | Email results |
| GET | `/allocation/:id/unallocated` | **NEW** Unallocated students |
| POST | `/allocation/:id/arrange` | **NEW** Manual seat arrange |

---

## Database (13 tables)

| # | Table | Purpose |
|---|-------|---------|
| 1 | `admins` | Admin accounts + OTP |
| 2 | `elections` | Election records + config |
| 3 | `students` | Student accounts |
| 4 | `pending_registrations` | Self-register queue |
| 5 | `courses` | Elective courses |
| 6 | `seats` | Global seat pool |
| 7 | `student_tokens` | FCFS booking tokens |
| 8 | `allocation_rounds` | Round history |
| 9 | `final_assignments` | Final allocation |
| 10 | `assignment_details` | Per-slot detail |
| 11 | `election_cav` | **v3** Join code + link |
| 12 | `election_participants` | **v3** Self-applied participants |
| 13 | `election_messages` | **v3** Expiring notifications |

---

## Key Design Decisions

- **Atomic booking** — `FOR UPDATE` row locks prevent double-booking
- **Rate limiting** — 20 bookings/minute per student
- **CAV expiry** — codes expire the moment election is stopped
- **Email-match gate** — apply email must match account email
- **One-per-election** — `UNIQUE KEY` enforces single application
- **Immutable results** — final_assignments never deleted after verification
- **Auto-assignment** — stopped elections auto-assign unused tokens (back-of-queue seats)

