import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Badge, Alert, Spinner, Modal } from '../../components/ui/index';
import api from '../../services/api';

/* ── SVG Waterfall bar ────────────────────────────────────── */
function WaterfallBar({ confirmed = 0, booked = 0, burst = 0, max = 1, height = 32, interactive }) {
  const [tip, setTip] = useState(null);
  const total = confirmed + booked + burst;
  const safe = max || 1;
  const segs = [
    { v: confirmed, c: '#059669', label: 'Confirmed' },
    { v: booked,    c: '#4F46E5', label: 'Booked' },
    { v: burst,     c: '#DC2626', label: 'Burst' },
    { v: Math.max(0, max - total), c: '#F1F5F9', label: 'Available' },
  ];
  return (
    <div style={{ position: 'relative' }}>
      <div style={{ display: 'flex', height, borderRadius: 8, overflow: 'hidden', gap: 1 }}>
        {segs.map((s, i) => (
          <div key={i}
            onMouseEnter={() => interactive && setTip({ label: s.label, v: s.v, color: s.c })}
            onMouseLeave={() => setTip(null)}
            style={{
              width: `${(s.v / safe) * 100}%`, background: s.c,
              transition: `width 0.7s cubic-bezier(0.34,1.2,0.64,1) ${i * 0.07}s`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '0.6rem', fontWeight: 700, color: 'white', overflow: 'hidden',
              minWidth: s.v > 0 ? 4 : 0,
            }}>
            {s.v > 0 && (s.v / safe) > 0.07 ? s.v : ''}
          </div>
        ))}
      </div>
      {tip && (
        <div style={{ position: 'absolute', bottom: '110%', left: '50%', transform: 'translateX(-50%)', background: '#0A0F1E', color: 'white', padding: '5px 10px', borderRadius: 8, fontSize: '0.72rem', whiteSpace: 'nowrap', pointerEvents: 'none', zIndex: 10, boxShadow: '0 4px 16px rgba(0,0,0,0.3)' }}>
          <span style={{ color: tip.color, fontWeight: 700 }}>●</span> {tip.label}: {tip.v}
        </div>
      )}
    </div>
  );
}

/* ── SVG Donut for overall stats ─────────────────────────── */
function StatsDonut({ confirmed, booked, burst, pending, size = 140 }) {
  const data = [
    { v: confirmed, c: '#059669', label: 'Confirmed' },
    { v: booked,    c: '#4F46E5', label: 'Booked' },
    { v: burst,     c: '#DC2626', label: 'Burst' },
    { v: pending,   c: '#D97706', label: 'Pending' },
  ].filter(d => d.v > 0);
  const total = data.reduce((s, d) => s + d.v, 0) || 1;
  const r = (size - 20) / 2;
  const circ = 2 * Math.PI * r;
  const [hov, setHov] = useState(null);
  let offset = 0;

  return (
    <div style={{ display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap' }}>
      <div style={{ position: 'relative', flexShrink: 0 }}>
        <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#F1F5F9" strokeWidth="18" />
          {data.map((seg, i) => {
            const dash = (seg.v / total) * circ;
            const arc = (
              <circle key={i} cx={size/2} cy={size/2} r={r} fill="none"
                stroke={seg.c} strokeWidth={hov === i ? 22 : 18}
                strokeDasharray={`${dash} ${circ - dash}`}
                strokeDashoffset={-offset} strokeLinecap="butt"
                onMouseEnter={() => setHov(i)} onMouseLeave={() => setHov(null)}
                style={{ transition: 'stroke-width 0.2s, stroke-dasharray 0.9s ease', filter: `drop-shadow(0 0 6px ${seg.c}66)`, cursor: 'default' }}
              />
            );
            offset += dash;
            return arc;
          })}
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', pointerEvents: 'none' }}>
          {hov !== null ? (
            <>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem', color: data[hov]?.c, letterSpacing: '-1px', lineHeight: 1 }}>{data[hov]?.v}</div>
              <div style={{ fontSize: '0.62rem', color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{data[hov]?.label}</div>
            </>
          ) : (
            <>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.5rem', color: 'var(--text)', letterSpacing: '-1px', lineHeight: 1 }}>{total}</div>
              <div style={{ fontSize: '0.62rem', color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>tokens</div>
            </>
          )}
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {data.map((seg, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'default' }}
            onMouseEnter={() => setHov(i)} onMouseLeave={() => setHov(null)}>
            <div style={{ width: 10, height: 10, borderRadius: 3, background: seg.c, flexShrink: 0, boxShadow: hov === i ? `0 0 8px ${seg.c}` : 'none', transition: 'box-shadow 0.2s' }} />
            <div style={{ fontSize: '0.8rem' }}>
              <span style={{ fontWeight: 600, color: 'var(--text-2)' }}>{seg.label}</span>
              <span style={{ color: 'var(--text-4)', marginLeft: 6, fontFamily: 'var(--mono)', fontSize: '0.76rem' }}>{seg.v}</span>
              <span style={{ color: 'var(--text-4)', fontSize: '0.7rem', marginLeft: 4 }}>({Math.round((seg.v / total) * 100)}%)</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Completion ring ──────────────────────────────────────── */
function CompletionRing({ value, max, size = 100 }) {
  const pct = max > 0 ? Math.min(1, value / max) : 0;
  const r = (size - 12) / 2;
  const circ = 2 * Math.PI * r;
  const color = pct === 1 ? '#059669' : pct > 0.7 ? '#4F46E5' : '#D97706';
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#F1F5F9" strokeWidth="11" />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth="11"
          strokeDasharray={`${pct * circ} ${circ}`} strokeLinecap="round"
          style={{ transition: 'stroke-dasharray 1.2s cubic-bezier(0.34,1.2,0.64,1)', filter: `drop-shadow(0 0 8px ${color}88)` }} />
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem', color, letterSpacing: '-1px', lineHeight: 1 }}>{Math.round(pct * 100)}%</div>
        <div style={{ fontSize: '0.58rem', color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.5px', marginTop: 2 }}>done</div>
      </div>
    </div>
  );
}

/* ── Course allocation card ───────────────────────────────── */
function CourseAllocCard({ c, roundNum, onConfirm, onBurst }) {
  const [hover, setHover] = useState(false);
  const booked = c.total_tokens || 0;
  const pct = Math.min(100, Math.round((booked / Math.max(c.max_enrollment, 1)) * 100));
  const viability = booked >= c.max_enrollment ? 'over' : booked >= c.min_enrollment ? 'viable' : 'low';
  const viabilityColor = viability === 'over' ? '#DC2626' : viability === 'viable' ? '#059669' : '#D97706';
  const viabilityLabel = viability === 'over' ? 'Over capacity' : viability === 'viable' ? 'Viable' : 'Under minimum';

  return (
    <div onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: c.is_burst ? '#FFF5F5' : 'var(--surface)',
        borderRadius: 16, padding: '18px 20px',
        border: `1.5px solid ${c.is_burst ? '#FECACA' : hover ? viabilityColor : 'var(--border)'}`,
        boxShadow: hover ? `0 8px 32px ${viabilityColor}18` : 'var(--shadow-sm)',
        transition: 'all 0.2s', opacity: c.is_burst ? 0.7 : 1,
      }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '0.62rem', fontWeight: 800, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '1.5px', fontFamily: 'var(--mono)', marginBottom: 4 }}>
            {c.subject_code || 'COURSE'}
          </div>
          <div style={{ fontWeight: 700, fontSize: '0.92rem', color: 'var(--text)', lineHeight: 1.3 }}>{c.course_name}</div>
        </div>
        {c.is_burst ? (
          <span style={{ background: '#FEF2F2', color: '#DC2626', border: '1px solid #FECACA', borderRadius: 8, padding: '4px 10px', fontSize: '0.7rem', fontWeight: 700, flexShrink: 0, marginLeft: 10 }}>BURST</span>
        ) : (
          <span style={{ background: `${viabilityColor}12`, color: viabilityColor, border: `1px solid ${viabilityColor}33`, borderRadius: 8, padding: '4px 10px', fontSize: '0.7rem', fontWeight: 700, flexShrink: 0, marginLeft: 10 }}>{viabilityLabel}</span>
        )}
      </div>

      {/* Token breakdown: T1 / T2 / T3 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 8, marginBottom: 12 }}>
        {[
          { label: 'T1', v: c.t1_count || 0, color: '#4F46E5' },
          { label: 'T2', v: c.t2_count || 0, color: '#7C3AED' },
          { label: 'T3', v: c.t3_count || 0, color: '#D97706' },
          { label: 'Total', v: booked, color: viabilityColor },
        ].map(m => (
          <div key={m.label} style={{ textAlign: 'center', background: 'var(--muted-bg)', borderRadius: 10, padding: '8px 4px' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.2rem', color: m.color, letterSpacing: '-0.5px', lineHeight: 1 }}>{m.v}</div>
            <div style={{ fontSize: '0.58rem', color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.5px', marginTop: 2 }}>{m.label}</div>
          </div>
        ))}
      </div>

      {/* Waterfall bar */}
      <div style={{ marginBottom: 8 }}>
        <WaterfallBar confirmed={0} booked={booked} burst={0} max={c.max_enrollment} height={24} interactive />
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.66rem', color: 'var(--text-4)', marginBottom: 14 }}>
        <span>min {c.min_enrollment}</span>
        <span>{pct}% of capacity</span>
        <span>max {c.max_enrollment}</span>
      </div>

      {/* Actions */}
      {!c.is_burst && (
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => onConfirm(c)} style={{ flex: 1, padding: '8px 0', background: 'linear-gradient(135deg, #059669, #10B981)', color: 'white', border: 'none', borderRadius: 10, fontWeight: 700, fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'var(--font)', boxShadow: '0 2px 8px rgba(5,150,105,0.35)', transition: 'all 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-1px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'none'}>
            ✓ Confirm
          </button>
          <button onClick={() => onBurst(c)} style={{ flex: 1, padding: '8px 0', background: 'linear-gradient(135deg, #DC2626, #EF4444)', color: 'white', border: 'none', borderRadius: 10, fontWeight: 700, fontSize: '0.8rem', cursor: 'pointer', fontFamily: 'var(--font)', boxShadow: '0 2px 8px rgba(220,38,38,0.3)', transition: 'all 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.transform = 'translateY(-1px)'}
            onMouseLeave={e => e.currentTarget.style.transform = 'none'}>
            ✕ Burst
          </button>
        </div>
      )}
    </div>
  );
}

/* ── Main ─────────────────────────────────────────────────── */
export default function AllocationPanel() {
  const [sp] = useSearchParams();
  const [elections, setElections] = useState([]);
  const [electionId, setElectionId] = useState(sp.get('id') || '');
  const [pool, setPool] = useState(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState('');
  const [msg, setMsg] = useState(null);
  const [verifyResult, setVerifyResult] = useState(null);
  const [roundNum, setRoundNum] = useState(1);
  const [confirmModal, setConfirmModal] = useState(null);
  const [burstModal, setBurstModal] = useState(null);
  const [capacity, setCapacity] = useState('');
  const [view, setView] = useState('cards');
  const [lastAction, setLastAction] = useState(null);
  const [tab, setTab] = useState('allocation'); // 'allocation' | 'unallocated'
  const [unallocated, setUnallocated] = useState([]);
  const [uloading, setUloading] = useState(false);
  const [arrangeOrder, setArrangeOrder] = useState('name');
  const [arranging, setArranging] = useState(false);

  useEffect(() => {
    api.get('/elections').then(r => {
      const list = r.data.data || [];
      setElections(list);
      if (!electionId) {
        const stopped = list.find(e => e.status === 'STOPPED');
        if (stopped) setElectionId(String(stopped.election_id));
      }
    });
  }, []); // eslint-disable-line

  const loadPool = useCallback(() => {
    if (!electionId) return;
    setLoading(true);
    api.get(`/allocation/${electionId}/pool`)
      .then(r => setPool(r.data))
      .catch(() => setMsg({ type: 'error', text: 'Failed to load pool.' }))
      .finally(() => setLoading(false));
  }, [electionId]);

  useEffect(() => { loadPool(); }, [loadPool]);

  const handleConfirm = async () => {
    setActionLoading('confirm'); setMsg(null);
    try {
      const { data } = await api.post('/allocation/confirm', {
        election_id: parseInt(electionId), course_id: confirmModal.course_id,
        capacity: parseInt(capacity), round_number: roundNum,
      });
      setMsg({ type: 'success', text: `✓ ${confirmModal.course_name}: ${data.confirmed} confirmed, ${data.burst} cascaded.` });
      setLastAction({ type: 'confirm', course: confirmModal.course_name, count: data.confirmed, time: new Date() });
      setConfirmModal(null); loadPool();
    } catch (err) { setMsg({ type: 'error', text: err.response?.data?.message || 'Confirm failed.' }); }
    finally { setActionLoading(''); }
  };

  const handleBurst = async () => {
    setActionLoading('burst'); setMsg(null);
    try {
      const { data } = await api.post('/allocation/burst', {
        election_id: parseInt(electionId), course_id: burstModal.course_id, round_number: roundNum,
      });
      setMsg({ type: 'success', text: `Burst: ${data.burst_count} students cascaded.` });
      setLastAction({ type: 'burst', course: burstModal.course_name, count: data.burst_count, time: new Date() });
      setBurstModal(null); loadPool();
    } catch (err) { setMsg({ type: 'error', text: err.response?.data?.message || 'Burst failed.' }); }
    finally { setActionLoading(''); }
  };

  const handleVerify = async () => {
    setActionLoading('verify');
    try { const { data } = await api.get(`/allocation/${electionId}/verify`); setVerifyResult(data); }
    catch { setMsg({ type: 'error', text: 'Verification failed.' }); }
    finally { setActionLoading(''); }
  };

  const handleExport = () => {
    const token = localStorage.getItem('ucos_token');
    const base = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
    fetch(`${base}/allocation/${electionId}/export`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.blob()).then(blob => {
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
        a.download = `ucos_allocation_${electionId}.csv`; document.body.appendChild(a); a.click(); document.body.removeChild(a);
      }).catch(() => setMsg({ type: 'error', text: 'Export failed.' }));
  };

  const handleEmail = async () => {
    if (!window.confirm('Send result emails to all students?')) return;
    setActionLoading('email');
    try { const { data } = await api.post(`/allocation/${electionId}/email`); setMsg({ type: 'success', text: data.message }); }
    catch { setMsg({ type: 'error', text: 'Email send failed.' }); }
    finally { setActionLoading(''); }
  };

  const loadUnallocated = useCallback(() => {
    if (!electionId) return;
    setUloading(true);
    api.get(`/allocation/${electionId}/unallocated`)
      .then(r => setUnallocated(r.data.data || []))
      .catch(() => {})
      .finally(() => setUloading(false));
  }, [electionId]);

  useEffect(() => {
    if (tab === 'unallocated') loadUnallocated();
  }, [tab, loadUnallocated]);

  const handleArrange = async () => {
    if (!window.confirm(`Auto-arrange ${unallocated.length} unallocated students by ${arrangeOrder}?`)) return;
    setArranging(true);
    try {
      const { data } = await api.post(`/allocation/${electionId}/arrange`, { order: arrangeOrder });
      setMsg({ type: 'success', text: data.message });
      loadUnallocated(); loadPool();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Arrange failed.' });
    } finally { setArranging(false); }
  };

  const totalConfirmed = pool?.stats?.confirmed || 0;
  const totalBooked    = pool?.stats?.booked || 0;
  const totalBurst     = pool?.stats?.burst || 0;
  const totalAuto      = pool?.stats?.auto_assigned || 0;
  const totalStudents  = pool?.stats?.total_students || 0;
  const pending        = pool?.students_pending || 0;
  const completionPct  = totalStudents > 0 ? Math.round((totalConfirmed / totalStudents) * 100) : 0;
  const viableCourses  = (pool?.pool || []).filter(c => !c.is_burst && (c.total_tokens || 0) >= c.min_enrollment).length;
  const burstCourses   = (pool?.pool || []).filter(c => c.is_burst).length;

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        {/* ── Header ── */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '1.7rem', fontWeight: 800, letterSpacing: '-0.6px', color: 'var(--text)', marginBottom: 4 }}>Allocation Panel</h1>
            <p style={{ fontSize: '0.84rem', color: 'var(--text-3)' }}>PWFCFS-MRA · Priority Weighted Multi-Round Allocation</p>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <select value={electionId} onChange={e => setElectionId(e.target.value)}
              style={{ padding: '8px 12px', borderRadius: 10, border: '1.5px solid var(--border)', fontSize: '0.85rem', fontFamily: 'var(--font)', color: 'var(--text)', background: 'var(--surface)', outline: 'none', minWidth: 200 }}>
              <option value="">— Select Election —</option>
              {elections.map(e => <option key={e.election_id} value={e.election_id}>{e.election_name}</option>)}
            </select>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--surface)', border: '1.5px solid var(--border)', borderRadius: 10, padding: '6px 12px' }}>
              <span style={{ fontSize: '0.72rem', fontWeight: 700, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Round</span>
              <input type="number" min="1" value={roundNum} onChange={e => setRoundNum(Math.max(1, parseInt(e.target.value) || 1))}
                style={{ width: 44, border: 'none', outline: 'none', fontFamily: 'var(--mono)', fontWeight: 800, fontSize: '1rem', background: 'transparent', color: 'var(--accent)', textAlign: 'center' }} />
            </div>
            {/* View toggle */}
            <div style={{ display: 'flex', background: 'var(--muted-bg)', borderRadius: 10, padding: 3, gap: 2 }}>
              {['cards', 'table'].map(v => (
                <button key={v} onClick={() => setView(v)}
                  style={{ padding: '5px 12px', borderRadius: 8, border: 'none', cursor: 'pointer', fontFamily: 'var(--font)', fontSize: '0.74rem', fontWeight: 600, background: view === v ? 'var(--surface)' : 'transparent', color: view === v ? 'var(--text)' : 'var(--text-4)', boxShadow: view === v ? 'var(--shadow-xs)' : 'none', transition: 'all 0.15s' }}>
                  {v === 'cards' ? '⊞ Cards' : '≡ Table'}
                </button>
              ))}
            </div>
            <button onClick={loadPool} disabled={loading}
              style={{ padding: '8px 14px', borderRadius: 10, border: '1.5px solid var(--border)', background: 'var(--surface)', cursor: 'pointer', fontFamily: 'var(--font)', fontSize: '0.82rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 6 }}>
              {loading ? <Spinner dark /> : '↻'} Refresh
            </button>
          </div>
        </div>

        {msg && <Alert type={msg.type}>{msg.text}</Alert>}
        {!electionId && <div className="alert alert-warning">Select a completed election above to begin allocation.</div>}

        {/* Tab bar */}
        {electionId && (
          <div style={{ display: 'flex', gap: 4, background: 'var(--muted-bg)', borderRadius: 12, padding: 4, marginBottom: 24, width: 'fit-content' }}>
            {[
              { id: 'allocation', label: '⊞ Allocation Rounds' },
              { id: 'unallocated', label: '⚠ Unallocated Seats' },
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                style={{ padding: '8px 18px', borderRadius: 9, border: 'none', cursor: 'pointer', fontFamily: 'var(--font)', fontSize: '0.82rem', fontWeight: 700, background: tab === t.id ? 'var(--surface)' : 'transparent', color: tab === t.id ? 'var(--text)' : 'var(--text-4)', boxShadow: tab === t.id ? 'var(--shadow-xs)' : 'none', transition: 'all 0.15s' }}>
                {t.label}
              </button>
            ))}
          </div>
        )}

        {electionId && !loading && pool && (
          <>
        {tab === 'allocation' && (<>
            {/* ── Top row: Donut + Completion Ring + Stats ── */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 20, marginBottom: 24, alignItems: 'start' }}>
              {/* Donut breakdown */}
              <div style={{ background: 'var(--surface)', borderRadius: 20, padding: '24px', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text)', marginBottom: 18 }}>Token Distribution</div>
                <StatsDonut confirmed={totalConfirmed} booked={totalBooked} burst={totalBurst} pending={pending} />
              </div>

              {/* Completion ring - center */}
              <div style={{ background: 'var(--surface)', borderRadius: 20, padding: '24px 32px', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12, minWidth: 180 }}>
                <div style={{ fontWeight: 700, fontSize: '0.88rem', color: 'var(--text)' }}>Completion</div>
                <CompletionRing value={totalConfirmed} max={totalStudents} />
                {completionPct === 100 && (
                  <div style={{ background: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 8, padding: '6px 14px', fontSize: '0.74rem', fontWeight: 700, color: '#065F46', textAlign: 'center' }}>
                    ✓ Allocation Complete!
                  </div>
                )}
              </div>

              {/* Quick stats */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {[
                  { label: 'Viable Courses', v: viableCourses, color: '#059669', icon: '✓' },
                  { label: 'Burst Courses',  v: burstCourses,  color: '#DC2626', icon: '✕' },
                  { label: 'Students Pending', v: pending,     color: '#D97706', icon: '⏳' },
                  { label: 'Auto-Assigned',  v: totalAuto,     color: '#7C3AED', icon: '⚡' },
                ].map(s => (
                  <div key={s.label} style={{ background: 'var(--surface)', borderRadius: 12, padding: '12px 16px', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: 12 }}>
                    <div style={{ width: 34, height: 34, borderRadius: 10, background: `${s.color}12`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1rem', flexShrink: 0 }}>{s.icon}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: '0.68rem', color: 'var(--text-4)', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>{s.label}</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.4rem', color: s.color, letterSpacing: '-0.5px', lineHeight: 1.1 }}>{s.v}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ── Last action toast ── */}
            {lastAction && (
              <div style={{ background: lastAction.type === 'confirm' ? '#ECFDF5' : '#FFF5F5', border: `1px solid ${lastAction.type === 'confirm' ? '#A7F3D0' : '#FECACA'}`, borderRadius: 12, padding: '12px 18px', marginBottom: 20, display: 'flex', alignItems: 'center', gap: 12, fontSize: '0.84rem' }}>
                <span style={{ fontSize: '1.2rem' }}>{lastAction.type === 'confirm' ? '✅' : '💥'}</span>
                <div>
                  <strong>{lastAction.course}</strong> — {lastAction.type === 'confirm' ? `${lastAction.count} students confirmed` : `${lastAction.count} students cascaded`}
                  <span style={{ color: 'var(--text-4)', marginLeft: 8, fontSize: '0.72rem' }}>{lastAction.time.toLocaleTimeString()}</span>
                </div>
                <button onClick={() => setLastAction(null)} style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-4)', fontSize: '1rem' }}>✕</button>
              </div>
            )}

            {/* ── Course Grid / Table ── */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text)' }}>
                Round {roundNum} — Course Allocation
              </div>
              <div style={{ fontSize: '0.76rem', color: 'var(--text-4)' }}>
                {(pool.pool || []).length} courses · {(pool.pool || []).filter(c => !c.is_burst).length} active
              </div>
            </div>

            {view === 'cards' ? (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px,1fr))', gap: 16, marginBottom: 24 }}>
                {(pool.pool || []).map(c => (
                  <CourseAllocCard key={c.course_id} c={c} roundNum={roundNum}
                    onConfirm={c => { setConfirmModal(c); setCapacity(String(Math.min(c.max_enrollment, c.total_tokens || 0))); }}
                    onBurst={c => setBurstModal(c)} />
                ))}
              </div>
            ) : (
              <div style={{ background: 'var(--surface)', borderRadius: 18, border: '1px solid var(--border)', overflow: 'hidden', marginBottom: 24 }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.84rem' }}>
                  <thead>
                    <tr>
                      {['Course', 'Code', 'T1', 'T2', 'T3', 'Total', 'Range', 'Distribution', 'Status', 'Actions'].map(h => (
                        <th key={h} style={{ padding: '11px 14px', background: 'var(--ink)', color: 'rgba(255,255,255,0.65)', fontWeight: 600, textAlign: 'left', fontSize: '0.66rem', textTransform: 'uppercase', letterSpacing: '0.8px', whiteSpace: 'nowrap' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(pool.pool || []).map(c => {
                      const booked = c.total_tokens || 0;
                      const viable = booked >= c.min_enrollment;
                      const color  = c.is_burst ? '#DC2626' : viable ? '#059669' : '#D97706';
                      return (
                        <tr key={c.course_id} style={{ borderBottom: '1px solid var(--border)', background: c.is_burst ? '#FFF5F5' : viable ? '#F0FDF7' : 'var(--surface)' }}>
                          <td style={{ padding: '11px 14px', fontWeight: 700, color: 'var(--text)' }}>{c.course_name}</td>
                          <td style={{ padding: '11px 14px' }}><span className="code-chip">{c.subject_code || '—'}</span></td>
                          <td style={{ padding: '11px 14px', fontFamily: 'var(--mono)', fontWeight: 700, color: '#4F46E5' }}>{c.t1_count || 0}</td>
                          <td style={{ padding: '11px 14px', fontFamily: 'var(--mono)', color: '#7C3AED' }}>{c.t2_count || 0}</td>
                          <td style={{ padding: '11px 14px', fontFamily: 'var(--mono)', color: '#D97706' }}>{c.t3_count || 0}</td>
                          <td style={{ padding: '11px 14px', fontFamily: 'var(--mono)', fontWeight: 800, color }}>{booked}</td>
                          <td style={{ padding: '11px 14px', fontFamily: 'var(--mono)', fontSize: '0.76rem', color: 'var(--text-3)', whiteSpace: 'nowrap' }}>{c.min_enrollment}–{c.max_enrollment}</td>
                          <td style={{ padding: '11px 14px', minWidth: 180 }}>
                            <WaterfallBar confirmed={0} booked={booked} burst={0} max={c.max_enrollment} height={22} />
                          </td>
                          <td style={{ padding: '11px 14px' }}>
                            <span style={{ background: `${color}12`, color, border: `1px solid ${color}33`, borderRadius: 6, padding: '3px 8px', fontSize: '0.68rem', fontWeight: 700 }}>
                              {c.is_burst ? 'Burst' : viable ? 'Viable' : 'Low'}
                            </span>
                          </td>
                          <td style={{ padding: '11px 14px' }}>
                            {!c.is_burst && (
                              <div style={{ display: 'flex', gap: 6 }}>
                                <button className="btn btn-success btn-sm" onClick={() => { setConfirmModal(c); setCapacity(String(Math.min(c.max_enrollment, booked))); }}>Confirm</button>
                                <button className="btn btn-danger btn-sm" onClick={() => setBurstModal(c)}>Burst</button>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* ── Verify & Publish ── */}
            <div style={{ background: 'var(--surface)', borderRadius: 20, padding: '24px', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)' }}>
              <div style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--text)', marginBottom: 18 }}>Finalise & Publish</div>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                {[
                  { label: '✓ Verify Allocation', action: handleVerify, loading: actionLoading === 'verify', cls: 'btn-navy' },
                  { label: '⬇ Download CSV', action: handleExport, loading: false, cls: 'btn-success' },
                  { label: '✉ Email All Students', action: handleEmail, loading: actionLoading === 'email', cls: 'btn-primary' },
                ].map(b => (
                  <button key={b.label} className={`btn ${b.cls}`} onClick={b.action} disabled={b.loading}>
                    {b.loading ? <Spinner /> : b.label}
                  </button>
                ))}
              </div>
              {verifyResult && (
                <div className={`alert mt-4 ${verifyResult.verified ? 'alert-success' : 'alert-error'}`} style={{ marginBottom: 0 }}>
                  {verifyResult.verified
                    ? `✓ Verified! ${verifyResult.total_students} students × ${verifyResult.required_per_student} courses = ${verifyResult.total_confirmed} allocations.`
                    : `⚠ Failed. ${verifyResult.flagged_students?.length || 0} students have incomplete allocation.`}
                </div>
              )}
            </div>
        </>)}

        {tab === 'unallocated' && (
          <div>
            {/* Controls */}
            <div style={{ background: 'var(--surface)', borderRadius: 20, padding: '24px', border: '1px solid var(--border)', boxShadow: 'var(--shadow-sm)', marginBottom: 20 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--text)', marginBottom: 4 }}>Manual Seat Arrangement</div>
                  <p style={{ fontSize: '0.82rem', color: 'var(--text-3)', lineHeight: 1.6 }}>
                    Students with unused tokens after the election stopped. Arrange them into remaining available seats. This action is final.
                  </p>
                </div>
                <button className="btn btn-surface btn-sm" onClick={loadUnallocated}>↻ Refresh</button>
              </div>

              {unallocated.length > 0 ? (
                <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
                  <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--text-3)' }}>Sort order:</div>
                  <div style={{ display: 'flex', gap: 4, background: 'var(--muted-bg)', borderRadius: 10, padding: 3 }}>
                    {[['name', 'Alphabetical (A–Z)'], ['register_number', 'Register Number']].map(([v, lbl]) => (
                      <button key={v} onClick={() => setArrangeOrder(v)}
                        style={{ padding: '5px 13px', borderRadius: 7, border: 'none', cursor: 'pointer', fontFamily: 'var(--font)', fontSize: '0.76rem', fontWeight: 700, background: arrangeOrder === v ? 'var(--surface)' : 'transparent', color: arrangeOrder === v ? 'var(--text)' : 'var(--text-4)', boxShadow: arrangeOrder === v ? 'var(--shadow-xs)' : 'none', transition: 'all 0.15s' }}>
                        {lbl}
                      </button>
                    ))}
                  </div>
                  <button className="btn btn-warning" onClick={handleArrange} disabled={arranging} style={{ marginLeft: 'auto' }}>
                    {arranging ? <Spinner /> : `⚡ Auto-Arrange ${unallocated.length} Students`}
                  </button>
                </div>
              ) : (
                <div style={{ padding: '20px', background: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 12, fontSize: '0.84rem', color: '#065F46', fontWeight: 600 }}>
                  ✅ All students have been allocated seats.
                </div>
              )}
            </div>

            {/* Unallocated list */}
            {uloading ? (
              <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>
            ) : unallocated.length > 0 && (
              <div style={{ background: 'var(--surface)', borderRadius: 20, border: '1px solid var(--border)', overflow: 'hidden', boxShadow: 'var(--shadow-sm)' }}>
                <div style={{ padding: '16px 22px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ fontWeight: 700, fontSize: '0.9rem', color: 'var(--text)' }}>Students with Unused Tokens</span>
                  <span style={{ background: '#FFFBEB', color: '#D97706', border: '1px solid #FDE68A', borderRadius: 99, padding: '3px 12px', fontSize: '0.72rem', fontWeight: 700 }}>{unallocated.length} students</span>
                </div>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.84rem' }}>
                  <thead>
                    <tr>
                      {['#', 'Name', 'Register No.', 'Section', 'Email', 'Unused Tokens', 'Pending Courses'].map(h => (
                        <th key={h} style={{ padding: '10px 16px', background: 'var(--ink)', color: 'rgba(255,255,255,0.6)', fontWeight: 600, textAlign: 'left', fontSize: '0.66rem', textTransform: 'uppercase', letterSpacing: '0.8px' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {unallocated.map((s, i) => (
                      <tr key={s.student_id} style={{ borderBottom: '1px solid var(--border)', background: i % 2 === 0 ? 'var(--surface)' : 'var(--muted-bg)' }}>
                        <td style={{ padding: '11px 16px', color: 'var(--text-4)', fontFamily: 'var(--mono)', fontSize: '0.76rem' }}>{i + 1}</td>
                        <td style={{ padding: '11px 16px', fontWeight: 700, color: 'var(--text)' }}>{s.name}</td>
                        <td style={{ padding: '11px 16px' }}><span className="code-chip" style={{ fontSize: '0.72rem' }}>{s.register_number}</span></td>
                        <td style={{ padding: '11px 16px' }}><span className="badge badge-blue">Sec {s.section}</span></td>
                        <td style={{ padding: '11px 16px', fontSize: '0.78rem', color: 'var(--text-3)' }}>{s.email}</td>
                        <td style={{ padding: '11px 16px', textAlign: 'center' }}>
                          <span style={{ fontFamily: 'var(--mono)', fontWeight: 800, fontSize: '1.1rem', color: '#D97706' }}>{s.unused_count}</span>
                        </td>
                        <td style={{ padding: '11px 16px', fontSize: '0.76rem', color: 'var(--text-3)', maxWidth: 220 }}>
                          <span style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.pending_courses || '—'}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
          </>
        )}

        {electionId && loading && <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>}

        {/* ── Confirm Modal ── */}
        {confirmModal && (
          <Modal title={`Confirm: ${confirmModal.course_name}`} onClose={() => setConfirmModal(null)}
            footer={<><button className="btn btn-surface btn-sm" onClick={() => setConfirmModal(null)}>Cancel</button><button className="btn btn-success" onClick={handleConfirm} disabled={actionLoading === 'confirm'}>{actionLoading === 'confirm' ? <Spinner /> : '✓ Confirm Course'}</button></>}>
            <div style={{ background: 'var(--emerald-light)', border: '1px solid #A7F3D0', borderRadius: 12, padding: '14px 16px', marginBottom: 16, fontSize: '0.84rem', color: '#065F46' }}>
              Pool: <strong>{confirmModal.total_tokens || 0}</strong> tokens · Min: {confirmModal.min_enrollment} · Max: {confirmModal.max_enrollment}
            </div>
            <WaterfallBar confirmed={0} booked={confirmModal.total_tokens || 0} burst={0} max={confirmModal.max_enrollment} height={28} />
            <div style={{ marginTop: 4, display: 'flex', gap: 10, fontSize: '0.68rem', color: 'var(--text-4)', marginBottom: 20 }}>
              <span>0</span><span style={{ marginLeft: 'auto' }}>min {confirmModal.min_enrollment}</span><span>max {confirmModal.max_enrollment}</span>
            </div>
            <div className="form-group">
              <label className="form-label">Seats to Confirm</label>
              <input className="form-input" type="number" value={capacity} onChange={e => setCapacity(e.target.value)} min="1" max={confirmModal.total_tokens || 999} />
              <div className="form-hint">Top {capacity || 0} students confirmed. {Math.max(0, (confirmModal.total_tokens || 0) - parseInt(capacity || 0))} cascade to next preference.</div>
            </div>
          </Modal>
        )}

        {/* ── Burst Modal ── */}
        {burstModal && (
          <Modal title={`Burst: ${burstModal.course_name}`} onClose={() => setBurstModal(null)}
            footer={<><button className="btn btn-surface btn-sm" onClick={() => setBurstModal(null)}>Cancel</button><button className="btn btn-danger" onClick={handleBurst} disabled={actionLoading === 'burst'}>{actionLoading === 'burst' ? <Spinner /> : '✕ Burst Course'}</button></>}>
            <div className="alert alert-error"><strong>This cannot be undone.</strong> All {burstModal.total_tokens || 0} tokens will be marked BURST and cascaded to next preferences.</div>
            <WaterfallBar confirmed={0} booked={burstModal.total_tokens || 0} burst={0} max={burstModal.max_enrollment} height={28} />
          </Modal>
        )}
      </main>
    </div>
  );
}
