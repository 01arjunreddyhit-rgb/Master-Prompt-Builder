const bcrypt = require('bcryptjs');
const pool = require('../config/db');
const csv = require('csv-parser');
const { Readable } = require('stream');

// ── GET PENDING REGISTRATIONS ─────────────────────────────────
const getPending = async (req, res) => {
  try {
    const admin_id = req.user.id;
    const [rows] = await pool.execute(
      `SELECT pending_id, name, register_number, email, section, status,
              is_email_verified, requested_at
       FROM pending_registrations
       WHERE admin_id=? ORDER BY requested_at DESC`,
      [admin_id]
    );
    res.json({ success: true, data: rows });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── APPROVE / REJECT PENDING ──────────────────────────────────
const reviewPending = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const admin_id = req.user.id;
    const { pending_id } = req.params;
    const { action } = req.body; // 'approve' or 'reject'

    const [rows] = await conn.execute(
      'SELECT * FROM pending_registrations WHERE pending_id=? AND admin_id=?',
      [pending_id, admin_id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Request not found.' });

    const p = rows[0];

    if (action === 'reject') {
      await conn.execute(
        'UPDATE pending_registrations SET status=?, reviewed_at=NOW() WHERE pending_id=?',
        ['REJECTED', pending_id]
      );
      return res.json({ success: true, message: 'Registration rejected.' });
    }

    if (action === 'approve') {
      await conn.beginTransaction();

      // Get active election for admin
      const [elections] = await conn.execute(
        "SELECT election_id, final_courses_per_student FROM elections WHERE admin_id=? AND status != 'STOPPED' ORDER BY created_at DESC LIMIT 1",
        [admin_id]
      );
      const election = elections[0] || null;

      const full_student_id = `PA${p.register_number}`;

      const [result] = await conn.execute(
        `INSERT INTO students
         (register_number, full_student_id, name, email, password_hash, section, admin_id, election_id, is_approved)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE)`,
        [p.register_number, full_student_id, p.name, p.email, p.password_hash,
         p.section, admin_id, election ? election.election_id : null]
      );
      const student_id = result.insertId;

      // Generate tokens if election exists
      if (election) {
        const [courses] = await conn.execute(
          'SELECT course_id FROM courses WHERE election_id=? AND is_active=TRUE',
          [election.election_id]
        );
        for (let i = 1; i <= courses.length; i++) {
          const token_code = `A${p.register_number}-T${i}`;
          await conn.execute(
            'INSERT INTO student_tokens (student_id, election_id, token_number, token_code) VALUES (?,?,?,?)',
            [student_id, election.election_id, i, token_code]
          );
        }
      }

      await conn.execute(
        'UPDATE pending_registrations SET status=?, reviewed_at=NOW() WHERE pending_id=?',
        ['APPROVED', pending_id]
      );

      await conn.commit();
      return res.json({ success: true, message: 'Student approved and account created.' });
    }

    res.status(400).json({ success: false, message: 'Invalid action. Use approve or reject.' });
  } catch (err) {
    await conn.rollback();
    console.error('reviewPending error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  } finally {
    conn.release();
  }
};

// ── UPLOAD STUDENTS VIA CSV ───────────────────────────────────
const uploadStudentsCSV = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const admin_id = req.user.id;
    if (!req.file) return res.status(400).json({ success: false, message: 'No CSV file uploaded.' });

    // Get active election
    const [elections] = await conn.execute(
      "SELECT election_id, final_courses_per_student FROM elections WHERE admin_id=? AND status='NOT_STARTED' ORDER BY created_at DESC LIMIT 1",
      [admin_id]
    );
    const election = elections[0] || null;

    // Get courses if election exists
    let courses = [];
    if (election) {
      const [c] = await conn.execute(
        'SELECT course_id FROM courses WHERE election_id=? AND is_active=TRUE',
        [election.election_id]
      );
      courses = c;
    }

    const students = [];
    const stream = Readable.from(req.file.buffer.toString());
    await new Promise((resolve, reject) => {
      stream.pipe(csv())
        .on('data', (row) => {
          const reg = (row.register_number || row.reg_no || row.reg || '').trim();
          const name = (row.name || row.student_name || '').trim();
          const email = (row.email || '').trim();
          const pass = (row.password || 'ucos@123').trim();
          const section = (row.section || 'A').trim().toUpperCase();
          if (reg && name && email) {
            students.push({ reg, name, email, pass, section });
          }
        })
        .on('end', resolve)
        .on('error', reject);
    });

    if (!students.length) {
      return res.status(400).json({ success: false, message: 'No valid rows found in CSV.' });
    }

    await conn.beginTransaction();
    let created = 0, skipped = 0;

    for (const s of students) {
      try {
        const [dup] = await conn.execute(
          'SELECT student_id FROM students WHERE email=? OR register_number=?',
          [s.email, s.reg]
        );
        if (dup.length) { skipped++; continue; }

        const hash = await bcrypt.hash(s.pass, 10);
        const full_id = `PA${s.reg}`;

        const [result] = await conn.execute(
          `INSERT INTO students
           (register_number, full_student_id, name, email, password_hash, section, admin_id, election_id, is_approved)
           VALUES (?,?,?,?,?,?,?,?,TRUE)`,
          [s.reg, full_id, s.name, s.email, hash, s.section, admin_id,
           election ? election.election_id : null]
        );
        const student_id = result.insertId;

        // Generate tokens
        if (election && courses.length > 0) {
          for (let i = 1; i <= courses.length; i++) {
            const token_code = `A${s.reg}-T${i}`;
            await conn.execute(
              'INSERT INTO student_tokens (student_id, election_id, token_number, token_code) VALUES (?,?,?,?)',
              [student_id, election.election_id, i, token_code]
            );
          }
        }
        created++;
      } catch (e) {
        skipped++;
      }
    }

    await conn.commit();
    res.json({
      success: true,
      message: `CSV processed: ${created} students created, ${skipped} skipped.`,
      created, skipped,
    });
  } catch (err) {
    await conn.rollback();
    console.error('uploadStudentsCSV error:', err);
    res.status(500).json({ success: false, message: 'Server error processing CSV.' });
  } finally {
    conn.release();
  }
};

// ── GET ALL STUDENTS ──────────────────────────────────────────
const getStudents = async (req, res) => {
  try {
    const admin_id = req.user.id;
    const { section, search } = req.query;

    let query = `
      SELECT s.student_id, s.register_number, s.full_student_id, s.name,
             s.email, s.section, s.is_approved, s.created_at,
             COUNT(CASE WHEN st.status='CONFIRMED' THEN 1 END) as confirmed_count,
             COUNT(CASE WHEN st.status IN ('BOOKED','CONFIRMED','AUTO') THEN 1 END) as booked_count
      FROM students s
      LEFT JOIN student_tokens st ON s.student_id = st.student_id
      WHERE s.admin_id=?
    `;
    const params = [admin_id];

    if (section) { query += ' AND s.section=?'; params.push(section); }
    if (search) { query += ' AND (s.name LIKE ? OR s.register_number LIKE ?)'; params.push(`%${search}%`, `%${search}%`); }

    query += ' GROUP BY s.student_id ORDER BY s.register_number ASC';

    const [rows] = await pool.execute(query, params);
    res.json({ success: true, data: rows, total: rows.length });
  } catch (err) {
    console.error('getStudents error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── DELETE STUDENT ────────────────────────────────────────────
const deleteStudent = async (req, res) => {
  try {
    const admin_id = req.user.id;
    const { student_id } = req.params;

    const [rows] = await pool.execute(
      'SELECT student_id FROM students WHERE student_id=? AND admin_id=?',
      [student_id, admin_id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Student not found.' });

    await pool.execute('DELETE FROM students WHERE student_id=?', [student_id]);
    res.json({ success: true, message: 'Student removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── GET SINGLE STUDENT ────────────────────────────────────────
const getStudentById = async (req, res) => {
  try {
    const admin_id = req.user.id;
    const { student_id } = req.params;
    const [rows] = await pool.execute(
      `SELECT s.*, e.election_name, e.status as election_status
       FROM students s
       LEFT JOIN elections e ON s.election_id = e.election_id
       WHERE s.student_id=? AND s.admin_id=?`,
      [student_id, admin_id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Student not found.' });
    const student = rows[0];

    const [tokens] = await pool.execute(
      `SELECT st.*, c.course_name, c.subject_code, se.seat_code
       FROM student_tokens st
       LEFT JOIN courses c ON st.course_id = c.course_id
       LEFT JOIN seats se ON st.seat_id = se.seat_id
       WHERE st.student_id=?
       ORDER BY st.token_number ASC`,
      [student_id]
    );
    res.json({ success: true, data: { ...student, tokens } });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── UPDATE ADMIN PROFILE ──────────────────────────────────────
const updateProfile = async (req, res) => {
  try {
    const admin_id = req.user.id;
    const { admin_name, college_name } = req.body;
    if (!admin_name || !college_name) {
      return res.status(400).json({ success: false, message: 'Name and institution required.' });
    }
    await pool.execute(
      'UPDATE admins SET admin_name=?, college_name=? WHERE admin_id=?',
      [admin_name, college_name, admin_id]
    );
    res.json({ success: true, message: 'Profile updated.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── CHANGE PASSWORD ───────────────────────────────────────────
const changePassword = async (req, res) => {
  try {
    const admin_id = req.user.id;
    const { current_password, new_password } = req.body;
    if (!current_password || !new_password) {
      return res.status(400).json({ success: false, message: 'Both passwords required.' });
    }
    if (new_password.length < 8) {
      return res.status(400).json({ success: false, message: 'New password must be at least 8 characters.' });
    }
    const [rows] = await pool.execute('SELECT password_hash FROM admins WHERE admin_id=?', [admin_id]);
    if (!rows.length) return res.status(404).json({ success: false, message: 'Admin not found.' });

    const valid = await bcrypt.compare(current_password, rows[0].password_hash);
    if (!valid) return res.status(401).json({ success: false, message: 'Current password is incorrect.' });

    const hash = await bcrypt.hash(new_password, 12);
    await pool.execute('UPDATE admins SET password_hash=? WHERE admin_id=?', [hash, admin_id]);
    res.json({ success: true, message: 'Password changed successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

module.exports = { getPending, reviewPending, uploadStudentsCSV, getStudents, getStudentById, deleteStudent, updateProfile, changePassword };
