import React, { useState, useEffect, useRef } from 'react';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Badge, EmptyState, Spinner } from '../../components/ui/index';
import api from '../../services/api';

export default function AdminStudents() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [search, setSearch] = useState('');
  const [section, setSection] = useState('');
  const [uploadResult, setUploadResult] = useState(null);
  const fileRef = useRef();

  const load = () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search)  params.set('search', search);
    if (section) params.set('section', section);
    api.get(`/admin/students?${params}`).then(r => {
      setStudents(r.data.data || []);
    }).catch(() => {}).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [search, section]); // eslint-disable-line

  const handleCSVUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true); setUploadResult(null);
    const form = new FormData();
    form.append('file', file);
    try {
      const { data } = await api.post('/admin/students/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setUploadResult({ success: true, message: data.message, created: data.created, skipped: data.skipped });
      load();
    } catch (err) {
      setUploadResult({ success: false, message: err.response?.data?.message || 'Upload failed.' });
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Remove ${name}? This cannot be undone.`)) return;
    await api.delete(`/admin/students/${id}`);
    load();
  };

  const sectionCounts = students.reduce((acc, s) => {
    acc[s.section] = (acc[s.section] || 0) + 1;
    return acc;
  }, {});

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Students</h1>
            <p className="page-subtitle">{students.length} students registered</p>
          </div>
          <div className="flex gap-2">
            <input type="file" accept=".csv" ref={fileRef} onChange={handleCSVUpload} style={{ display: 'none' }} />
            <button className="btn btn-primary" onClick={() => fileRef.current.click()} disabled={uploading}>
              {uploading ? <Spinner /> : '⬆ Upload CSV'}
            </button>
          </div>
        </div>

        {/* Upload result */}
        {uploadResult && (
          <div className={`alert alert-${uploadResult.success ? 'success' : 'error'}`}>
            {uploadResult.message}
            {uploadResult.success && ` Created: ${uploadResult.created}, Skipped: ${uploadResult.skipped}`}
          </div>
        )}

        {/* CSV format hint */}
        <div className="card mb-4">
          <div className="card-header"><span className="card-title">CSV Format</span></div>
          <code style={{ fontSize: '0.78rem', color: 'var(--navy)', background: 'var(--lgrey)', padding: '10px 14px', borderRadius: 7, display: 'block', fontFamily: 'var(--mono)' }}>
            serial_no, register_number, name, email, password, section<br />
            1, 2301107031, Harikrishna, hari@college.edu, pass123, A<br />
            2, 2301107032, Bharanidharan, bhar@college.edu, pass456, A
          </code>
          <p className="text-xs text-muted" style={{ marginTop: 8 }}>If password column is missing, default password <strong>ucos@123</strong> is used.</p>
        </div>

        {/* Section stats */}
        {Object.keys(sectionCounts).length > 0 && (
          <div className="stat-grid mb-4">
            {Object.entries(sectionCounts).map(([sec, cnt]) => (
              <div key={sec} className="stat-card">
                <div className="stat-label">Section {sec}</div>
                <div className="stat-value">{cnt}</div>
                <div className="stat-sub">students</div>
              </div>
            ))}
          </div>
        )}

        {/* Filters */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">All Students</span>
            <div className="flex gap-2">
              <input className="form-input" placeholder="Search name or reg no..."
                value={search} onChange={e => setSearch(e.target.value)}
                style={{ width: 200 }} />
              <select className="form-select" value={section}
                onChange={e => setSection(e.target.value)} style={{ width: 120 }}>
                <option value="">All Sections</option>
                {['A','B','C','D','E'].map(s => <option key={s} value={s}>Section {s}</option>)}
              </select>
            </div>
          </div>

          {loading ? (
            <div style={{ textAlign: 'center', padding: 40 }}><Spinner dark /></div>
          ) : students.length === 0 ? (
            <EmptyState icon="👥" title="No students yet"
              message="Upload a CSV file to add students in bulk." />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Register No.</th><th>Student ID</th><th>Name</th>
                    <th>Section</th><th>Email</th><th>Tokens Booked</th><th>Confirmed</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {students.map(s => (
                    <tr key={s.student_id}>
                      <td><span className="code-chip">{s.register_number}</span></td>
                      <td><span className="code-chip">{s.full_student_id}</span></td>
                      <td><strong>{s.name}</strong></td>
                      <td><Badge variant="blue">Sec {s.section}</Badge></td>
                      <td className="text-sm text-muted">{s.email}</td>
                      <td>{s.booked_count || 0}</td>
                      <td>
                        {s.confirmed_count > 0
                          ? <Badge variant="green">{s.confirmed_count} confirmed</Badge>
                          : <Badge variant="grey">0</Badge>}
                      </td>
                      <td>
                        <button className="btn btn-danger btn-sm"
                          onClick={() => handleDelete(s.student_id, s.name)}>
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
