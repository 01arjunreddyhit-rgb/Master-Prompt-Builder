import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { StatCard, StatusPill, Spinner, EmptyState } from '../../components/ui/index';
import api from '../../services/api';

export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [elections, setElections] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/elections').then(r => {
      setElections(r.data.data || []);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  const current = elections.find(e => ['NOT_STARTED','ACTIVE','PAUSED'].includes(e.status));

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header">
          <h1 className="page-title">Welcome back, {user?.admin_name?.split(' ')[0]}</h1>
          <p className="page-subtitle">{user?.college_name} · {user?.admin_id}</p>
        </div>

        {/* Quick stats */}
        <div className="stat-grid">
          <StatCard label="Total Elections" value={elections.length} color="" />
          <StatCard label="Students" value={current?.student_count ?? '—'} color="green" sub={current ? 'This election' : 'No active election'} />
          <StatCard label="Courses" value={current?.course_count ?? '—'} color="orange" sub="Active" />
          <StatCard label="Election Status" value={current ? <StatusPill status={current.status} /> : '—'} />
        </div>

        {/* Current election card */}
        <div className="card mb-6">
          <div className="card-header">
            <span className="card-title">Current Election</span>
            <button className="btn btn-primary btn-sm" onClick={() => navigate('/admin/election')}>
              Manage →
            </button>
          </div>
          {loading ? (
            <div style={{ textAlign: 'center', padding: 32 }}><Spinner dark /></div>
          ) : current ? (
            <div>
              <h3 style={{ fontSize: '1.1rem', color: 'var(--navy)', marginBottom: 8 }}>
                {current.election_name}
              </h3>
              <div className="flex gap-4 items-center" style={{ flexWrap: 'wrap', gap: 12 }}>
                <StatusPill status={current.status} />
                <span className="badge badge-blue">Sem: {current.semester_tag || '—'}</span>
                <span className="badge badge-grey">Batch: {current.batch_tag || '—'}</span>
                <span className="badge badge-green">{current.final_courses_per_student} courses/student</span>
              </div>
              <div className="grid-3 mt-4" style={{ gap: 12 }}>
                <div style={{ background: 'var(--lgrey)', borderRadius: 8, padding: '12px 16px' }}>
                  <div className="stat-label">Students</div>
                  <div style={{ fontSize: '1.4rem', fontWeight: 700 }}>{current.student_count ?? 0}</div>
                </div>
                <div style={{ background: 'var(--lgrey)', borderRadius: 8, padding: '12px 16px' }}>
                  <div className="stat-label">Courses</div>
                  <div style={{ fontSize: '1.4rem', fontWeight: 700 }}>{current.course_count ?? 0}</div>
                </div>
                <div style={{ background: 'var(--lgrey)', borderRadius: 8, padding: '12px 16px' }}>
                  <div className="stat-label">Faculty</div>
                  <div style={{ fontSize: '1.4rem', fontWeight: 700 }}>{current.faculty_count ?? 0}</div>
                </div>
              </div>
            </div>
          ) : (
            <EmptyState icon="🗳️" title="No active election"
              message="Create your first election to get started."
              action={<button className="btn btn-primary" onClick={() => navigate('/admin/election')}>Create Election</button>}
            />
          )}
        </div>

        {/* Quick actions */}
        <div className="card">
          <div className="card-header"><span className="card-title">Quick Actions</span></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 12 }}>
            {[
              { label: '+ Add Students',   path: '/admin/students',  color: 'btn-primary' },
              { label: '+ Create Course',  path: '/admin/courses',   color: 'btn-warning' },
              { label: 'Election Control', path: '/admin/election',  color: 'btn-success' },
              { label: 'Allocation Panel', path: '/admin/allocation',color: 'btn-navy' },
            ].map(a => (
              <button key={a.path} className={`btn ${a.color}`} onClick={() => navigate(a.path)}>
                {a.label}
              </button>
            ))}
          </div>
        </div>

        {/* Past elections */}
        {elections.filter(e => e.status === 'STOPPED').length > 0 && (
          <div className="card mt-4">
            <div className="card-header"><span className="card-title">Past Elections</span></div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Name</th><th>Semester</th><th>Students</th><th>Status</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {elections.filter(e => e.status === 'STOPPED').map(e => (
                    <tr key={e.election_id}>
                      <td><strong>{e.election_name}</strong></td>
                      <td>{e.semester_tag || '—'}</td>
                      <td>{e.student_count}</td>
                      <td><StatusPill status={e.status} /></td>
                      <td>
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => navigate(`/admin/allocation?id=${e.election_id}`)}>
                          View Results
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
