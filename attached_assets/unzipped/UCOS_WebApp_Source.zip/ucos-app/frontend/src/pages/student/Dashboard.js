import React, { useState, useEffect, useCallback } from 'react';
import { StudentSidebar } from '../../components/ui/Sidebar';
import { StatusPill, Alert, Spinner, Modal, ProgressBar, TokenChip } from '../../components/ui/index';
import api from '../../services/api';

// ── BOOKING CONFIRMATION POPUP ────────────────────────────────
function BookingPopup({ course, nextToken, onConfirm, onCancel, loading }) {
  return (
    <Modal title="Course Booking Confirmation" onClose={onCancel}
      footer={
        <>
          <button className="btn btn-ghost" onClick={onCancel} disabled={loading}>Cancel</button>
          <button className="btn btn-primary" onClick={onConfirm} disabled={loading}>
            {loading ? <Spinner /> : 'Confirm & Book'}
          </button>
        </>
      }>
      <div className="booking-detail">
        <div className="booking-detail-row">
          <span className="booking-detail-label">Course</span>
          <span className="booking-detail-value">{course.course_name}</span>
        </div>
        <div className="booking-detail-row">
          <span className="booking-detail-label">Code</span>
          <span className="booking-detail-value">{course.subject_code || '—'}</span>
        </div>
        <div className="booking-detail-row">
          <span className="booking-detail-label">Token Used</span>
          <span className="booking-detail-value" style={{ color: 'var(--accent)' }}>
            {nextToken?.token_code}
          </span>
        </div>
        <div className="booking-detail-row">
          <span className="booking-detail-label">Seats Available</span>
          <span className="booking-detail-value" style={{ color: course.available_seats < 20 ? 'var(--red)' : 'var(--dkgreen)' }}>
            {course.available_seats} / {course.total_seats}
          </span>
        </div>
        <div className="booking-detail-row">
          <span className="booking-detail-label">Priority</span>
          <span className="booking-detail-value">T{nextToken?.token_number} (#{nextToken?.token_number} preference)</span>
        </div>
      </div>
      <div className="alert alert-warning" style={{ fontSize: '0.82rem' }}>
        ⚠ This action cannot be undone. Your token will be used automatically.
        You must select all {course.final_courses_per_student || 'all'} courses.
      </div>
    </Modal>
  );
}

// ── SUCCESS POPUP ─────────────────────────────────────────────
function SuccessPopup({ booking, onClose }) {
  return (
    <Modal title="✓ Seat Secured!" onClose={onClose}
      footer={<button className="btn btn-success btn-full" onClick={onClose}>Back to Dashboard</button>}>
      <div className="success-icon">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
      </div>
      <div className="success-seat">{booking.seat_code}</div>
      <p className="text-center text-muted text-sm mb-4">Your seat number</p>
      <div className="booking-detail">
        <div className="booking-detail-row">
          <span className="booking-detail-label">Token Used</span>
          <span className="booking-detail-value" style={{ color: 'var(--accent)' }}>{booking.token_code}</span>
        </div>
        <div className="booking-detail-row">
          <span className="booking-detail-label">Course</span>
          <span className="booking-detail-value">{booking.course_name}</span>
        </div>
        <div className="booking-detail-row">
          <span className="booking-detail-label">Booked At</span>
          <span className="booking-detail-value">{new Date(booking.booked_at).toLocaleString()}</span>
        </div>
      </div>
      <div className="alert alert-info" style={{ fontSize: '0.82rem', marginTop: 8 }}>
        💡 Keep booking your remaining courses before the election closes!
      </div>
    </Modal>
  );
}

// ── MAIN DASHBOARD ────────────────────────────────────────────
export default function StudentDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bookingCourse, setBookingCourse] = useState(null);
  const [successBooking, setSuccessBooking] = useState(null);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api.get('/student/dashboard').then(r => setData(r.data))
      .catch(() => setError('Failed to load dashboard.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  // Auto-refresh every 15s during active election
  useEffect(() => {
    if (data?.student?.election_status !== 'ACTIVE') return;
    const iv = setInterval(load, 15000);
    return () => clearInterval(iv);
  }, [data?.student?.election_status, load]);

  const nextToken = data?.tokens?.find(t => t.status === 'UNUSED');

  const confirmBooking = async () => {
    if (!bookingCourse || !nextToken) return;
    setBookingLoading(true); setError('');
    try {
      const { data: res } = await api.post('/student/book', {
        course_id: bookingCourse.course_id,
        election_id: data.student.election_id,
      });
      setBookingCourse(null);
      setSuccessBooking(res.booking);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed. Please try again.');
      setBookingCourse(null);
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Spinner dark />
      </main>
    </div>
  );

  const { student, tokens = [], courses = [], stats = {} } = data || {};
  const isActive = student?.election_status === 'ACTIVE';
  const bookedCount = stats.booked || 0;
  const totalTokens = stats.total_tokens || 0;

  return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content">
        {/* Header */}
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Welcome, {student?.name?.split(' ')[0]}</h1>
            <p className="page-subtitle">
              {student?.full_student_id} · Section {student?.section} · {student?.email}
            </p>
          </div>
          {student?.election_status && <StatusPill status={student.election_status} />}
        </div>

        {error && <Alert type="error">{error}</Alert>}

        {/* Election inactive notice */}
        {!isActive && student?.election_status && (
          <Alert type={student.election_status === 'STOPPED' ? 'info' : 'warning'}>
            {student.election_status === 'STOPPED'
              ? 'Election has ended. View your results in My Results.'
              : student.election_status === 'PAUSED'
              ? 'Election is paused. Booking temporarily suspended.'
              : 'Election has not started yet. Check back later.'}
          </Alert>
        )}

        {/* Token status bar */}
        {tokens.length > 0 && (
          <div className="card mb-4">
            <div className="card-header">
              <span className="card-title">Token Status</span>
              <span className="text-sm text-muted">{bookedCount} of {totalTokens} used</span>
            </div>
            <div className="token-bar">
              {tokens.map(t => (
                <TokenChip key={t.token_id} number={t.token_number}
                  status={t.status === 'UNUSED' && t.token_number === nextToken?.token_number ? 'UNUSED' : t.status}
                  courseName={t.course_name} />
              ))}
            </div>
            <ProgressBar value={bookedCount} max={totalTokens} green />
            <p className="text-xs text-muted mt-2">
              {totalTokens - bookedCount} course{totalTokens - bookedCount !== 1 ? 's' : ''} remaining to select
            </p>
          </div>
        )}

        {/* Course grid */}
        {courses.length > 0 && (
          <div>
            <h2 style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--navy)', marginBottom: 12 }}>
              {isActive ? 'Select Your Courses — Click OPT to book' : 'Available Courses'}
            </h2>
            <div className="course-grid">
              {courses.map(c => {
                const pct = c.total_seats > 0 ? ((c.total_seats - c.available_seats) / c.total_seats) : 0;
                const booked = c.is_booked_by_me;
                const myToken = booked ? tokens.find(t => t.course_id === c.course_id) : null;
                return (
                  <div key={c.course_id} className={`course-card ${booked ? 'booked' : ''}`}>
                    <div className="course-card-badge">{c.subject_code || 'ELECTIVE'}</div>
                    <div className="course-card-name">{c.course_name}</div>
                    <div className="text-sm text-muted">
                      {c.available_seats} seats remaining
                    </div>
                    <div className="seat-bar">
                      <div className={`seat-bar-fill ${pct > 0.8 ? 'crit' : pct > 0.6 ? 'warn' : ''}`}
                        style={{ width: `${pct * 100}%` }} />
                    </div>
                    <div className="course-card-actions">
                      <div>
                        {booked && myToken && (
                          <span className="code-chip">{myToken.token_code}</span>
                        )}
                      </div>
                      {booked ? (
                        <span className="badge badge-green">✓ Booked</span>
                      ) : isActive && nextToken ? (
                        <button className="btn btn-primary btn-sm"
                          onClick={() => setBookingCourse(c)}>
                          OPT →
                        </button>
                      ) : (
                        <span className="badge badge-grey">{isActive ? 'All tokens used' : 'Closed'}</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Booking popup */}
        {bookingCourse && (
          <BookingPopup
            course={bookingCourse}
            nextToken={nextToken}
            onConfirm={confirmBooking}
            onCancel={() => setBookingCourse(null)}
            loading={bookingLoading}
          />
        )}

        {/* Success popup */}
        {successBooking && (
          <SuccessPopup booking={successBooking} onClose={() => setSuccessBooking(null)} />
        )}
      </main>
    </div>
  );
}
