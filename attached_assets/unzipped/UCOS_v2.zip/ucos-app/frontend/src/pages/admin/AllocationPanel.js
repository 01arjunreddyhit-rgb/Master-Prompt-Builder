import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Badge, Alert, Spinner, Modal, ProgressBar } from '../../components/ui/index';
import api from '../../services/api';

/* ── Demand bar for each course ─────────────────────────────── */
function DemandBar({ total, min, max }) {
  const pct = Math.min(100, Math.round((total / Math.max(max, 1)) * 100));
  const isAtMin  = total >= min;
  const isAtMax  = total >= max;
  const barClass = isAtMax ? 'over' : isAtMin ? 'full' : '';
  return (
    <div>
      <div className="demand-bar-wrap">
        <div className={`demand-bar-fill ${barClass}`} style={{ width: `${pct}%`, minWidth: total > 0 ? 32 : 0 }}>
          {pct >= 20 ? `${pct}%` : ''}
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.66rem', color: 'var(--text-4)', marginTop: 3 }}>
        <span>{total} booked</span>
        <span>max {max}</span>
      </div>
    </div>
  );
}

/* ── Round history timeline ─────────────────────────────────── */
function RoundHistory({ rounds = [] }) {
  if (!rounds.length) return null;
  return (
    <div className="card mb-4">
      <div className="card-header"><span className="card-title">Round History</span></div>
      <div style={{ position: 'relative', paddingLeft: 22 }}>
        <div style={{ position: 'absolute', left: 6, top: 4, bottom: 4, width: 2, background: 'var(--border)', borderRadius: 2 }} />
        {rounds.map((r, i) => (
          <div key={i} style={{ position: 'relative', marginBottom: 16 }}>
            <div style={{ position: 'absolute', left: -19, top: 4, width: 10, height: 10, borderRadius: '50%', background: 'var(--emerald)', border: '2px solid var(--surface)', boxShadow: '0 0 0 2px var(--emerald-light)' }} />
            <div style={{ fontSize: '0.68rem', color: 'var(--text-4)', fontFamily: 'var(--mono)', marginBottom: 2 }}>Round {r.round_number}</div>
            <div style={{ fontSize: '0.84rem', fontWeight: 600, color: 'var(--text-2)' }}>{r.confirmed_count} confirmed · {r.burst_count} burst</div>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Main ──────────────────────────────────────────────────── */
export default function AllocationPanel() {
  const [sp] = useSearchParams();
  const [elections, setElections] = useState([]);
  const [electionId, setElectionId] = useState(sp.get('id') || '');
  const [pool, setPool] = useState(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState('');
  const [msg, setMsg] = useState(null);
  const [verifyResult, setVerifyResult] = useState(null);
  const [roundNum, setRoundNum] = useState(1);
  const [confirmModal, setConfirmModal] = useState(null);
  const [burstModal, setBurstModal] = useState(null);
  const [capacity, setCapacity] = useState('');

  useEffect(() => {
    api.get('/elections').then(r => {
      const list = r.data.data || [];
      setElections(list);
      if (!electionId) {
        const stopped = list.find(e => e.status === 'STOPPED');
        if (stopped) setElectionId(String(stopped.election_id));
      }
    });
  }, []); // eslint-disable-line

  const loadPool = useCallback(() => {
    if (!electionId) return;
    setLoading(true);
    api.get(`/allocation/${electionId}/pool`)
      .then(r => setPool(r.data))
      .catch(() => setMsg({ type: 'error', text: 'Failed to load allocation pool.' }))
      .finally(() => setLoading(false));
  }, [electionId]);

  useEffect(() => { loadPool(); }, [loadPool]);

  const handleConfirm = async () => {
    setActionLoading('confirm'); setMsg(null);
    try {
      const { data } = await api.post('/allocation/confirm', {
        election_id: parseInt(electionId), course_id: confirmModal.course_id,
        capacity: parseInt(capacity), round_number: roundNum,
      });
      setMsg({ type: 'success', text: `✓ ${confirmModal.course_name}: ${data.confirmed} confirmed, ${data.burst} cascaded.` });
      setConfirmModal(null); loadPool();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Confirm failed.' });
    } finally { setActionLoading(''); }
  };

  const handleBurst = async () => {
    setActionLoading('burst'); setMsg(null);
    try {
      const { data } = await api.post('/allocation/burst', {
        election_id: parseInt(electionId), course_id: burstModal.course_id, round_number: roundNum,
      });
      setMsg({ type: 'success', text: `Course burst. ${data.burst_count} students cascaded.` });
      setBurstModal(null); loadPool();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Burst failed.' });
    } finally { setActionLoading(''); }
  };

  const handleVerify = async () => {
    setActionLoading('verify');
    try {
      const { data } = await api.get(`/allocation/${electionId}/verify`);
      setVerifyResult(data);
    } catch { setMsg({ type: 'error', text: 'Verification failed.' }); }
    finally { setActionLoading(''); }
  };

  const handleExport = () => {
    const token = localStorage.getItem('ucos_token');
    const base = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
    fetch(`${base}/allocation/${electionId}/export`, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.blob())
      .then(blob => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `ucos_allocation_${electionId}.csv`;
        document.body.appendChild(link); link.click(); document.body.removeChild(link);
      })
      .catch(() => setMsg({ type: 'error', text: 'Export failed.' }));
  };

  const handleEmail = async () => {
    if (!window.confirm('Send result emails to all students?')) return;
    setActionLoading('email');
    try {
      const { data } = await api.post(`/allocation/${electionId}/email`);
      setMsg({ type: 'success', text: data.message });
    } catch { setMsg({ type: 'error', text: 'Email send failed.' }); }
    finally { setActionLoading(''); }
  };

  const totalConfirmed   = pool?.stats?.confirmed || 0;
  const totalBooked      = pool?.stats?.booked || 0;
  const totalBurst       = pool?.stats?.burst || 0;
  const totalAuto        = pool?.stats?.auto_assigned || 0;
  const totalStudents    = pool?.stats?.total_students || 0;
  const completionPct    = totalStudents > 0 ? Math.round((totalConfirmed / totalStudents) * 100) : 0;

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Allocation Panel</h1>
            <p className="page-subtitle">PWFCFS-MRA — Priority Weighted Multi-Round Allocation</p>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <select className="form-select" value={electionId} onChange={e => setElectionId(e.target.value)} style={{ width: 220, height: 36, padding: '0 12px' }}>
              <option value="">Select Election</option>
              {elections.map(e => <option key={e.election_id} value={e.election_id}>{e.election_name}</option>)}
            </select>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, background: 'var(--surface)', border: '1.5px solid var(--border)', borderRadius: 10, padding: '5px 12px' }}>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-3)', fontWeight: 600 }}>Round</span>
              <input type="number" min="1" value={roundNum}
                onChange={e => setRoundNum(parseInt(e.target.value))}
                style={{ width: 48, border: 'none', outline: 'none', fontFamily: 'var(--mono)', fontWeight: 700, fontSize: '0.9rem', background: 'transparent', color: 'var(--accent)' }} />
            </div>
            <button className="btn btn-surface btn-sm" onClick={loadPool} disabled={loading}>
              {loading ? <Spinner dark /> : '↻ Refresh'}
            </button>
          </div>
        </div>

        {msg && <Alert type={msg.type}>{msg.text}</Alert>}

        {!electionId ? (
          <div className="alert alert-warning">Select a stopped election above to run allocation.</div>
        ) : loading ? (
          <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>
        ) : pool ? (
          <>
            {/* ── Stats ── */}
            <div className="stat-grid mb-4">
              {[
                { label: 'Total Tokens', value: totalStudents, variant: '' },
                { label: 'Confirmed',    value: totalConfirmed, variant: 'green' },
                { label: 'Booked',       value: totalBooked, variant: '' },
                { label: 'Burst',        value: totalBurst, variant: 'red' },
                { label: 'Auto-Assigned',value: totalAuto, variant: 'purple' },
                { label: 'Pending',      value: pool.students_pending || 0, variant: 'orange' },
              ].map(s => (
                <div key={s.label} className={`stat-card ${s.variant}`}>
                  <div className="stat-label">{s.label}</div>
                  <div className="stat-value" style={{ fontSize: '1.8rem' }}>{s.value}</div>
                </div>
              ))}
            </div>

            {/* ── Overall completion progress ── */}
            {totalStudents > 0 && (
              <div className="card mb-4">
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10, alignItems: 'center' }}>
                  <span className="card-title">Overall Completion</span>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <span style={{ fontFamily: 'var(--font-display)', fontSize: '1.8rem', fontWeight: 800, color: completionPct === 100 ? 'var(--emerald)' : 'var(--accent)', letterSpacing: '-1px' }}>{completionPct}%</span>
                    {completionPct === 100 && <span className="badge badge-green">Complete ✓</span>}
                  </div>
                </div>
                <ProgressBar value={totalConfirmed} max={totalStudents} green={completionPct >= 80} />
                <div style={{ fontSize: '0.78rem', color: 'var(--text-4)', marginTop: 6 }}>
                  {totalConfirmed} of {totalStudents} tokens confirmed · {pool.students_pending || 0} students still need allocation
                </div>
              </div>
            )}

            {/* ── Course Demand Table ── */}
            <div className="card mb-4">
              <div className="card-header">
                <span className="card-title">Round {roundNum} — Course Demand</span>
                <span className="text-xs text-muted">{pool.pool?.length || 0} courses</span>
              </div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr><th>Course</th><th>Code</th><th>T1</th><th>T2</th><th>T3</th><th>Total</th><th>Min / Max</th><th style={{ minWidth: 160 }}>Demand</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {(pool.pool || []).map(c => (
                      <tr key={c.course_id} className={c.is_burst ? 'alloc-row-burst' : c.total_tokens >= c.min_enrollment ? 'alloc-row-confirmed' : ''}>
                        <td><strong style={{ color: 'var(--text)' }}>{c.course_name}</strong></td>
                        <td><span className="code-chip">{c.subject_code || '—'}</span></td>
                        <td style={{ fontFamily: 'var(--mono)', fontWeight: 700 }}>{c.t1_count || 0}</td>
                        <td style={{ fontFamily: 'var(--mono)' }}>{c.t2_count || 0}</td>
                        <td style={{ fontFamily: 'var(--mono)' }}>{c.t3_count || 0}</td>
                        <td><strong style={{ fontFamily: 'var(--mono)', color: 'var(--text)' }}>{c.total_tokens || 0}</strong></td>
                        <td style={{ fontFamily: 'var(--mono)', fontSize: '0.8rem', color: 'var(--text-3)' }}>{c.min_enrollment} / {c.max_enrollment}</td>
                        <td style={{ minWidth: 160 }}>
                          <DemandBar total={c.total_tokens || 0} min={c.min_enrollment} max={c.max_enrollment} />
                        </td>
                        <td>
                          {c.is_burst ? (
                            <Badge variant="red">Burst</Badge>
                          ) : (
                            <div style={{ display: 'flex', gap: 6 }}>
                              <button className="btn btn-success btn-sm"
                                onClick={() => { setConfirmModal(c); setCapacity(String(Math.min(c.max_enrollment, c.total_tokens || 0))); }}>
                                Confirm
                              </button>
                              <button className="btn btn-danger btn-sm"
                                onClick={() => setBurstModal(c)}>
                                Burst
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* ── Finalise ── */}
            <div className="card">
              <div className="card-header"><span className="card-title">Finalise & Publish</span></div>
              <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                <button className="btn btn-navy" onClick={handleVerify} disabled={actionLoading === 'verify'}>
                  {actionLoading === 'verify' ? <Spinner /> : '✓ Verify Allocation'}
                </button>
                <button className="btn btn-success" onClick={handleExport}>
                  ⬇ Download CSV
                </button>
                <button className="btn btn-primary" onClick={handleEmail} disabled={actionLoading === 'email'}>
                  {actionLoading === 'email' ? <Spinner /> : '✉ Email All Students'}
                </button>
              </div>

              {verifyResult && (
                <div className={`alert mt-4 ${verifyResult.verified ? 'alert-success' : 'alert-error'}`} style={{ marginBottom: 0 }}>
                  {verifyResult.verified ? (
                    <>✓ Allocation verified! {verifyResult.total_students} students × {verifyResult.required_per_student} courses = {verifyResult.total_confirmed} confirmed.</>
                  ) : (
                    <>⚠ Verification failed. {verifyResult.flagged_students?.length || 0} students have incomplete allocation.</>
                  )}
                </div>
              )}
            </div>
          </>
        ) : null}

        {/* ── Confirm Modal ── */}
        {confirmModal && (
          <Modal title={`Confirm: ${confirmModal.course_name}`} onClose={() => setConfirmModal(null)}
            footer={
              <>
                <button className="btn btn-surface btn-sm" onClick={() => setConfirmModal(null)}>Cancel</button>
                <button className="btn btn-success btn-sm" onClick={handleConfirm} disabled={actionLoading === 'confirm'}>
                  {actionLoading === 'confirm' ? <Spinner /> : 'Confirm Course'}
                </button>
              </>
            }>
            <div className="alert alert-info">
              Pool: <strong>{confirmModal.total_tokens || 0}</strong> tokens &nbsp;·&nbsp;
              Min: {confirmModal.min_enrollment} &nbsp;·&nbsp; Max: {confirmModal.max_enrollment}
            </div>
            <DemandBar total={confirmModal.total_tokens || 0} min={confirmModal.min_enrollment} max={confirmModal.max_enrollment} />
            <div className="form-group mt-4">
              <label className="form-label">Seats to Confirm</label>
              <input className="form-input" type="number" value={capacity}
                onChange={e => setCapacity(e.target.value)}
                min="1" max={confirmModal.total_tokens || 999} />
              <div className="form-hint">
                Top-{capacity || 0} students (by seat number) will be CONFIRMED.
                Remaining {Math.max(0, (confirmModal.total_tokens || 0) - parseInt(capacity || 0))} will cascade to their next token.
              </div>
            </div>
          </Modal>
        )}

        {/* ── Burst Modal ── */}
        {burstModal && (
          <Modal title={`Burst: ${burstModal.course_name}`} onClose={() => setBurstModal(null)}
            footer={
              <>
                <button className="btn btn-surface btn-sm" onClick={() => setBurstModal(null)}>Cancel</button>
                <button className="btn btn-danger btn-sm" onClick={handleBurst} disabled={actionLoading === 'burst'}>
                  {actionLoading === 'burst' ? <Spinner /> : 'Burst Course'}
                </button>
              </>
            }>
            <div className="alert alert-error">
              <strong>This cannot be undone.</strong> All {burstModal.total_tokens || 0} booked tokens will be marked BURST and cascaded.
            </div>
            <DemandBar total={burstModal.total_tokens || 0} min={burstModal.min_enrollment} max={burstModal.max_enrollment} />
            <div style={{ marginTop: 16, fontSize: '0.87rem', color: 'var(--text-2)' }}>
              Bursting will cascade each student individually to their next available token preference.
            </div>
          </Modal>
        )}
      </main>
    </div>
  );
}
