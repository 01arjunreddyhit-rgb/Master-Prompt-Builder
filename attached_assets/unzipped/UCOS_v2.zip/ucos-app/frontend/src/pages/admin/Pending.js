import React, { useState, useEffect } from 'react';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Badge, EmptyState, Spinner, Alert } from '../../components/ui/index';
import api from '../../services/api';

export default function AdminPending() {
  const [pending, setPending] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);

  const load = () => {
    setLoading(true);
    api.get('/admin/pending').then(r => setPending(r.data.data || []))
      .catch(() => {}).finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const review = async (id, action, name) => {
    if (action === 'approve' && !window.confirm(`Approve ${name}?`)) return;
    if (action === 'reject' && !window.confirm(`Reject ${name}?`)) return;
    try {
      await api.post(`/admin/pending/${id}`, { action });
      setMsg({ type: 'success', text: `${name} ${action}d.` });
      load();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Action failed.' });
    }
  };

  const waiting = pending.filter(p => p.status === 'PENDING');
  const done = pending.filter(p => p.status !== 'PENDING');

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header">
          <h1 className="page-title">Pending Approvals</h1>
          <p className="page-subtitle">{waiting.length} students awaiting approval</p>
        </div>

        {msg && <Alert type={msg.type}>{msg.text}</Alert>}

        <div className="card">
          <div className="card-header"><span className="card-title">Awaiting Approval</span></div>
          {loading ? (
            <div style={{ textAlign: 'center', padding: 40 }}><Spinner dark /></div>
          ) : waiting.length === 0 ? (
            <EmptyState icon="✅" title="All clear" message="No pending registrations." />
          ) : (
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Name</th><th>Reg No</th><th>Email</th><th>Section</th><th>Email Verified</th><th>Requested</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {waiting.map(p => (
                    <tr key={p.pending_id}>
                      <td><strong>{p.name}</strong></td>
                      <td><span className="code-chip">{p.register_number}</span></td>
                      <td className="text-sm">{p.email}</td>
                      <td><Badge variant="blue">Sec {p.section}</Badge></td>
                      <td>{p.is_email_verified
                        ? <Badge variant="green">Verified</Badge>
                        : <Badge variant="orange">Pending</Badge>}
                      </td>
                      <td className="text-sm text-muted">{new Date(p.requested_at).toLocaleDateString()}</td>
                      <td>
                        <div className="flex gap-2">
                          <button className="btn btn-success btn-sm" onClick={() => review(p.pending_id, 'approve', p.name)}>
                            Approve
                          </button>
                          <button className="btn btn-danger btn-sm" onClick={() => review(p.pending_id, 'reject', p.name)}>
                            Reject
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {done.length > 0 && (
          <div className="card mt-4">
            <div className="card-header"><span className="card-title">Reviewed</span></div>
            <div className="table-wrap">
              <table>
                <thead><tr><th>Name</th><th>Reg No</th><th>Status</th><th>Reviewed</th></tr></thead>
                <tbody>
                  {done.map(p => (
                    <tr key={p.pending_id}>
                      <td>{p.name}</td>
                      <td><span className="code-chip">{p.register_number}</span></td>
                      <td><Badge variant={p.status === 'APPROVED' ? 'green' : 'red'}>{p.status}</Badge></td>
                      <td className="text-sm text-muted">{p.reviewed_at ? new Date(p.reviewed_at).toLocaleDateString() : '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
