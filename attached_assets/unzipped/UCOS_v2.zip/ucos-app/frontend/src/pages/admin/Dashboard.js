import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { StatusPill, Spinner, Badge } from '../../components/ui/index';
import api from '../../services/api';

/* ── Animated counter hook ─────────────────────────────────── */
function useCounter(target, duration = 900) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (target == null || isNaN(target)) return;
    const start = performance.now();
    const tick = (now) => {
      const t = Math.min((now - start) / duration, 1);
      const ease = 1 - Math.pow(1 - t, 3);
      setVal(Math.round(ease * target));
      if (t < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [target, duration]);
  return val;
}

/* ── Mini donut (SVG) ──────────────────────────────────────── */
function Donut({ pct = 0, color = '#4F46E5', size = 60, stroke = 7 }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const dash = (pct / 100) * circ;
  return (
    <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#E2E8F0" strokeWidth={stroke} />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeDasharray={`${dash} ${circ}`}
        strokeLinecap="round"
        style={{ transition: 'stroke-dasharray 0.7s cubic-bezier(0.34,1.2,0.64,1)' }} />
    </svg>
  );
}

/* ── Sparkline bars ────────────────────────────────────────── */
function SparkBars({ data = [], color = '#4F46E5' }) {
  const max = Math.max(...data, 1);
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 3, height: 36 }}>
      {data.map((v, i) => (
        <div key={i} style={{
          flex: 1, borderRadius: '3px 3px 0 0', minHeight: 3,
          background: i === data.length - 1 ? color : `${color}55`,
          height: `${(v / max) * 100}%`,
          transition: 'height 0.5s ease',
        }} />
      ))}
    </div>
  );
}

/* ── Main ──────────────────────────────────────────────────── */
export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [elections, setElections] = useState([]);
  const [studentCount, setStudentCount] = useState(null);
  const [pendingCount, setPendingCount] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    Promise.all([
      api.get('/elections'),
      api.get('/admin/students'),
      api.get('/admin/pending'),
    ]).then(([elecRes, studRes, pendRes]) => {
      setElections(elecRes.data.data || []);
      setStudentCount(studRes.data.total || 0);
      const pending = (pendRes.data.data || []).filter(p => p.status === 'PENDING');
      setPendingCount(pending.length);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const current = elections.find(e => ['NOT_STARTED','ACTIVE','PAUSED'].includes(e.status));
  const past    = elections.filter(e => e.status === 'STOPPED');

  const studVal    = useCounter(studentCount ?? 0);
  const pendVal    = useCounter(pendingCount ?? 0);
  const elecVal    = useCounter(elections.length);
  const courseVal  = useCounter(current?.course_count ?? 0);

  const bookingPct = current && current.student_count > 0
    ? Math.round(((current.student_count - (current.student_count || 0)) / current.student_count) * 100)
    : 0;

  // Fake weekly trend data for visual interest (would be real in prod)
  const sparkData = [12, 18, 9, 24, 15, 28, studentCount ?? 0].map(v => Math.max(v, 1));

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">

        {/* ── Header ── */}
        <div className="page-header flex justify-between items-center">
          <div>
            <div style={{ fontSize: '0.76rem', fontWeight: 700, color: 'var(--text-4)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: 4 }}>{greeting}</div>
            <h1 className="page-title">{user?.admin_name?.split(' ')[0]}'s Dashboard</h1>
            <p className="page-subtitle">{user?.college_name} &nbsp;·&nbsp; <span className="code-chip">{user?.admin_id}</span></p>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {current && <StatusPill status={current.status} />}
            <button className="btn btn-surface btn-sm" onClick={load}>↻ Refresh</button>
          </div>
        </div>

        {/* ── KPI Row ── */}
        <div className="stat-grid animate-in">
          {[
            { label: 'Total Students', value: studVal, sub: 'All time', variant: 'green', icon: '👨‍🎓' },
            { label: 'Pending Approvals', value: pendVal, sub: pendingCount > 0 ? '⚠ Needs review' : '✓ All clear', variant: pendingCount > 0 ? 'orange' : '', icon: '⏳' },
            { label: 'Active Courses', value: courseVal, sub: current ? current.election_name : 'No active election', variant: '', icon: '📚' },
            { label: 'Total Elections', value: elecVal, sub: `${past.length} completed`, variant: 'purple', icon: '🗳️' },
          ].map((s, i) => (
            <div key={i} className={`stat-card ${s.variant}`}>
              <div className="stat-label">{s.label}</div>
              <div className="stat-value">{loading ? <div className="skeleton" style={{ width: 60, height: 36 }} /> : s.value}</div>
              <div className="stat-sub">{s.sub}</div>
            </div>
          ))}
        </div>

        {/* ── Two Column: Active Election + Quick Actions ── */}
        <div className="grid-2 mb-4">

          {/* Active Election Panel */}
          <div className="card" style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            <div className="card-header">
              <span className="card-title">Active Election</span>
              <button className="btn btn-ghost btn-sm" onClick={() => navigate('/admin/election')}>Manage →</button>
            </div>

            {loading ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[80, 50, 100, 60].map((w, i) => <div key={i} className="skeleton" style={{ height: 16, width: `${w}%` }} />)}
              </div>
            ) : current ? (
              <>
                <div style={{ marginBottom: 18 }}>
                  <div style={{ fontWeight: 700, fontSize: '1rem', color: 'var(--text)', marginBottom: 8, lineHeight: 1.3 }}>{current.election_name}</div>
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    <StatusPill status={current.status} />
                    {current.semester_tag && <Badge variant="blue">{current.semester_tag}</Badge>}
                    {current.batch_tag && <Badge variant="grey">{current.batch_tag}</Badge>}
                    <Badge variant="green">{current.final_courses_per_student} courses/student</Badge>
                  </div>
                </div>

                {/* Stats with donut */}
                <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 18 }}>
                  <div style={{ position: 'relative', flexShrink: 0 }}>
                    <Donut pct={current.student_count > 0 ? Math.min(100, (courseVal / Math.max(current.final_courses_per_student, 1)) * 10) : 0} />
                    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'var(--mono)', fontSize: '0.75rem', fontWeight: 700 }}>
                      {current.student_count ?? 0}
                    </div>
                  </div>
                  <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
                    {[
                      { label: 'Students enrolled', value: current.student_count ?? 0 },
                      { label: 'Active courses', value: current.course_count ?? 0 },
                      { label: 'Faculty count', value: current.faculty_count ?? 0 },
                    ].map(row => (
                      <div key={row.label} style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.84rem' }}>
                        <span style={{ color: 'var(--text-3)' }}>{row.label}</span>
                        <span style={{ fontWeight: 700, fontFamily: 'var(--mono)', fontSize: '0.82rem' }}>{row.value}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action buttons by status */}
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 'auto' }}>
                  {current.status === 'NOT_STARTED' && (
                    <button className="btn btn-success btn-sm" onClick={() => navigate('/admin/election')}>▶ Start Election</button>
                  )}
                  {current.status === 'ACTIVE' && (
                    <button className="btn btn-warning btn-sm" onClick={() => navigate('/admin/election')}>⏸ Pause</button>
                  )}
                  {(current.status === 'ACTIVE' || current.status === 'PAUSED') && (
                    <button className="btn btn-danger btn-sm" onClick={() => navigate('/admin/election')}>⏹ Stop</button>
                  )}
                  {current.status === 'STOPPED' && (
                    <button className="btn btn-primary btn-sm" onClick={() => navigate(`/admin/allocation?id=${current.election_id}`)}>📊 Allocation Panel →</button>
                  )}
                  <button className="btn btn-surface btn-sm" onClick={() => navigate('/admin/students')}>Students</button>
                  <button className="btn btn-surface btn-sm" onClick={() => navigate('/admin/courses')}>Courses</button>
                </div>
              </>
            ) : (
              <div style={{ textAlign: 'center', padding: '28px 0', color: 'var(--text-3)' }}>
                <div style={{ fontSize: '2.5rem', marginBottom: 10 }}>🗳️</div>
                <div style={{ fontWeight: 600, color: 'var(--text-2)', marginBottom: 6 }}>No active election</div>
                <div style={{ fontSize: '0.84rem', marginBottom: 20 }}>Create one to get started with UCOS</div>
                <button className="btn btn-primary btn-sm" onClick={() => navigate('/admin/election')}>Create Election →</button>
              </div>
            )}
          </div>

          {/* Right column: Quick Actions + Sparkline */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

            {/* Quick actions */}
            <div className="card">
              <div className="card-header"><span className="card-title">Quick Actions</span></div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
                {[
                  { label: '⬆ Upload Students', path: '/admin/students',   cls: 'btn-primary' },
                  { label: '➕ Add Course',      path: '/admin/courses',    cls: 'btn-success' },
                  { label: '🗳 Election',        path: '/admin/election',   cls: 'btn-navy' },
                  { label: '⏳ Pending',         path: '/admin/pending',    cls: pendingCount > 0 ? 'btn-warning' : 'btn-surface' },
                  { label: '📊 Allocation',      path: '/admin/allocation', cls: 'btn-surface' },
                  { label: '👤 Profile',         path: '/admin/profile',    cls: 'btn-surface' },
                ].map(a => (
                  <button key={a.path} className={`btn btn-sm ${a.cls}`}
                    onClick={() => navigate(a.path)}
                    style={{ justifyContent: 'flex-start', fontSize: '0.79rem' }}>
                    {a.label}
                    {a.path === '/admin/pending' && pendingCount > 0 && (
                      <span style={{ marginLeft: 'auto', background: 'var(--red)', color: 'white', fontSize: '0.6rem', padding: '1px 5px', borderRadius: 99, fontWeight: 700 }}>{pendingCount}</span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Sparkline activity card */}
            <div className="card" style={{ flex: 1 }}>
              <div className="card-header">
                <span className="card-title">Student Activity</span>
                <span className="badge badge-green" style={{ fontSize: '0.6rem' }}>↑ Trend</span>
              </div>
              <SparkBars data={sparkData} color="#4F46E5" />
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: 'var(--text-4)', marginTop: 8 }}>
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span style={{ color: 'var(--accent)', fontWeight: 700 }}>Now</span>
              </div>
            </div>
          </div>
        </div>

        {/* ── Past Elections ── */}
        {past.length > 0 && (
          <div className="card">
            <div className="card-header">
              <span className="card-title">Past Elections</span>
              <Badge variant="grey">{past.length}</Badge>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Election</th><th>Semester</th><th>Batch</th><th>Students</th><th>Courses</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                  {past.map(e => (
                    <tr key={e.election_id}>
                      <td><strong style={{ color: 'var(--text)' }}>{e.election_name}</strong></td>
                      <td>{e.semester_tag || <span className="text-muted">—</span>}</td>
                      <td>{e.batch_tag || <span className="text-muted">—</span>}</td>
                      <td><span className="code-chip">{e.student_count ?? '—'}</span></td>
                      <td><span className="code-chip">{e.course_count ?? '—'}</span></td>
                      <td><StatusPill status={e.status} /></td>
                      <td>
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => navigate(`/admin/allocation?id=${e.election_id}`)}>
                          Results →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* First-time empty state */}
        {!loading && elections.length === 0 && (
          <div className="card" style={{ textAlign: 'center', padding: '64px 24px' }}>
            <div style={{ fontSize: '4rem', marginBottom: 16, animation: 'float 3s ease-in-out infinite' }}>🗳️</div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 800, color: 'var(--text)', marginBottom: 8, letterSpacing: '-0.3px' }}>Welcome to UCOS</h3>
            <p style={{ color: 'var(--text-3)', marginBottom: 28, maxWidth: 380, margin: '0 auto 28px' }}>
              Start by creating your first election. Add courses, upload students, then launch the election for fair elective allocation.
            </p>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
              <button className="btn btn-primary" onClick={() => navigate('/admin/election')}>Create First Election →</button>
              <button className="btn btn-surface" onClick={() => navigate('/admin/students')}>Upload Students</button>
            </div>
          </div>
        )}
      </main>

      <style>{`@keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }`}</style>
    </div>
  );
}
