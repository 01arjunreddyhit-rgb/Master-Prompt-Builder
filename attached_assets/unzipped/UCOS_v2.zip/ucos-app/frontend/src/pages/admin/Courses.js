import React, { useState, useEffect } from 'react';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Badge, EmptyState, Spinner, Modal } from '../../components/ui/index';
import api from '../../services/api';

export default function AdminCourses() {
  const [courses, setCourses] = useState([]);
  const [activeElection, setActiveElection] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editCourse, setEditCourse] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    course_name: '', subject_code: '', description: '',
    min_enrollment: 45, max_enrollment: 75,
    classes_per_course: 1, credit_weight: 3.0,
  });

  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }));

  const load = async () => {
    setLoading(true);
    try {
      const er = await api.get('/elections');
      const elecs = er.data.data || [];
      const active = elecs.find(e => ['NOT_STARTED','ACTIVE','PAUSED'].includes(e.status));
      setActiveElection(active || null);
      if (active) {
        const cr = await api.get(`/courses?election_id=${active.election_id}`);
        setCourses(cr.data.data || []);
      }
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  useEffect(() => { load(); }, []); // eslint-disable-line

  const openAdd = () => {
    setEditCourse(null);
    setForm({ course_name: '', subject_code: '', description: '', min_enrollment: 45, max_enrollment: 75, classes_per_course: 1, credit_weight: 3.0 });
    setShowModal(true);
  };

  const openEdit = (c) => {
    setEditCourse(c);
    setForm({ course_name: c.course_name, subject_code: c.subject_code || '', description: c.description || '', min_enrollment: c.min_enrollment, max_enrollment: c.max_enrollment, classes_per_course: c.classes_per_course, credit_weight: c.credit_weight });
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!form.course_name.trim()) return alert('Course name required.');
    setSaving(true);
    try {
      if (editCourse) {
        await api.put(`/courses/${editCourse.course_id}`, form);
      } else {
        await api.post('/courses', { ...form, election_id: activeElection.election_id });
      }
      setShowModal(false);
      load();
    } catch (err) {
      alert(err.response?.data?.message || 'Save failed.');
    }
    setSaving(false);
  };

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete course "${name}"?`)) return;
    try { await api.delete(`/courses/${id}`); load(); }
    catch (err) { alert(err.response?.data?.message || 'Delete failed.'); }
  };

  const toggleActive = async (c) => {
    await api.put(`/courses/${c.course_id}`, { is_active: !c.is_active });
    load();
  };

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <h1 className="page-title">Courses</h1>
            <p className="page-subtitle">
              {activeElection ? `Election: ${activeElection.election_name}` : 'No active election'}
            </p>
          </div>
          {activeElection && <button className="btn btn-primary" onClick={openAdd}>+ Add Course</button>}
        </div>

        {!activeElection && !loading && (
          <div className="alert alert-warning">No active election. Create one in <strong>Election Control</strong> first.</div>
        )}

        {loading ? (
          <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>
        ) : courses.length === 0 && activeElection ? (
          <EmptyState icon="📚" title="No courses yet" message="Add elective courses for this election."
            action={<button className="btn btn-primary" onClick={openAdd}>Add First Course</button>} />
        ) : (
          <div className="card">
            <div className="card-header">
              <span className="card-title">{courses.length} Courses</span>
              <span className="badge badge-blue">{courses.filter(c => c.is_active).length} active</span>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>#</th><th>Course Name</th><th>Code</th><th>Min</th><th>Max</th><th>Booked</th><th>Status</th><th>Actions</th></tr>
                </thead>
                <tbody>
                  {courses.map((c, i) => (
                    <tr key={c.course_id}>
                      <td className="text-muted text-sm">{i + 1}</td>
                      <td>
                        <strong>{c.course_name}</strong>
                        {c.description && <div className="text-xs text-muted">{c.description}</div>}
                      </td>
                      <td><span className="code-chip">{c.subject_code || '—'}</span></td>
                      <td>{c.min_enrollment}</td>
                      <td>{c.max_enrollment}</td>
                      <td><strong>{c.token_count || 0}</strong> <span className="text-muted text-xs">/ {c.total_seats}</span></td>
                      <td>
                        {c.is_burst ? <Badge variant="red">Burst</Badge>
                          : c.is_active ? <Badge variant="green">Active</Badge>
                          : <Badge variant="grey">Inactive</Badge>}
                      </td>
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button className="btn btn-ghost btn-sm" onClick={() => openEdit(c)}>Edit</button>
                          {!c.is_burst && (
                            <button className={`btn btn-sm ${c.is_active ? 'btn-warning' : 'btn-success'}`} onClick={() => toggleActive(c)}>
                              {c.is_active ? 'Deactivate' : 'Activate'}
                            </button>
                          )}
                          <button className="btn btn-danger btn-sm" onClick={() => handleDelete(c.course_id, c.course_name)}>Del</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {showModal && (
          <Modal
            title={editCourse ? 'Edit Course' : 'Add New Course'}
            onClose={() => setShowModal(false)}
            footer={
              <>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowModal(false)}>Cancel</button>
                <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>
                  {saving ? <Spinner /> : editCourse ? 'Save Changes' : 'Add Course'}
                </button>
              </>
            }
          >
            <div className="form-group">
              <label className="form-label">Course Name *</label>
              <input className="form-input" placeholder="Machine Learning" value={form.course_name} onChange={set('course_name')} />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Subject Code</label>
                <input className="form-input" placeholder="ML301" value={form.subject_code} onChange={set('subject_code')} />
              </div>
              <div className="form-group">
                <label className="form-label">Credit Weight</label>
                <input className="form-input" type="number" step="0.5" value={form.credit_weight} onChange={set('credit_weight')} />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Min Enrollment</label>
                <input className="form-input" type="number" value={form.min_enrollment} onChange={set('min_enrollment')} />
              </div>
              <div className="form-group">
                <label className="form-label">Max Enrollment</label>
                <input className="form-input" type="number" value={form.max_enrollment} onChange={set('max_enrollment')} />
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Description (optional)</label>
              <textarea className="form-textarea" rows={2} placeholder="Brief description..." value={form.description} onChange={set('description')} />
            </div>
          </Modal>
        )}
      </main>
    </div>
  );
}
