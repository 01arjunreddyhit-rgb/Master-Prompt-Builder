import React, { useState, useEffect, useCallback } from 'react';
import { StudentSidebar } from '../../components/ui/Sidebar';
import { StatusPill, Alert, Spinner, Modal, ProgressBar, TokenChip } from '../../components/ui/index';
import api from '../../services/api';

/* ── Seat urgency color ─────────────────────────────────────── */
function urgency(available, total) {
  if (!total) return { color: 'var(--text-4)', label: '—', level: 'ok' };
  const pct = available / total;
  if (pct > 0.5) return { color: 'var(--emerald)', label: 'Available', level: 'ok' };
  if (pct > 0.2) return { color: 'var(--amber)', label: 'Filling up', level: 'warn' };
  if (pct > 0)   return { color: 'var(--red)', label: 'Almost full!', level: 'crit' };
  return { color: 'var(--red)', label: 'Full', level: 'crit' };
}

/* ── Booking Popup ──────────────────────────────────────────── */
function BookingPopup({ course, nextToken, coursesRequired, onConfirm, onCancel, loading }) {
  const u = urgency(course.available_seats, course.total_seats);
  return (
    <Modal title="Confirm Booking" onClose={onCancel}
      footer={
        <>
          <button className="btn btn-surface btn-sm" onClick={onCancel} disabled={loading}>Cancel</button>
          <button className="btn btn-primary" onClick={onConfirm} disabled={loading}>
            {loading ? <Spinner /> : '🎫 Confirm & Book'}
          </button>
        </>
      }>
      {/* Course header */}
      <div style={{ background: 'linear-gradient(135deg, #4F46E5, #6366F1)', borderRadius: 12, padding: '18px 20px', marginBottom: 18, color: 'white' }}>
        <div style={{ fontSize: '0.68rem', fontWeight: 700, opacity: 0.75, letterSpacing: '1.5px', textTransform: 'uppercase', fontFamily: 'var(--mono)', marginBottom: 4 }}>
          {course.subject_code || 'ELECTIVE'}
        </div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: '1.1rem', letterSpacing: '-0.3px' }}>{course.course_name}</div>
        <div style={{ marginTop: 10, display: 'flex', gap: 16, fontSize: '0.82rem', opacity: 0.85 }}>
          <span>{course.available_seats} seats left</span>
          <span style={{ color: u.color === 'var(--red)' ? '#FCA5A5' : u.color === 'var(--amber)' ? '#FCD34D' : '#86EFAC' }}>● {u.label}</span>
        </div>
      </div>

      <div className="booking-detail">
        {[
          ['Token Used',      nextToken?.token_code, 'var(--accent)'],
          ['Priority Level',  `T${nextToken?.token_number} — #${nextToken?.token_number} preference`, null],
          ['Seats Available', `${course.available_seats} / ${course.total_seats}`, u.color],
        ].map(([label, value, color]) => (
          <div key={label} className="booking-detail-row">
            <span className="booking-detail-label">{label}</span>
            <span className="booking-detail-value" style={color ? { color } : {}}>{value}</span>
          </div>
        ))}
      </div>

      <div className="alert alert-warning" style={{ fontSize: '0.82rem', marginTop: 4 }}>
        ⚠ This cannot be undone. You must select all {coursesRequired || 'required'} courses.
      </div>
    </Modal>
  );
}

/* ── Success Popup ──────────────────────────────────────────── */
function SuccessPopup({ booking, onClose }) {
  return (
    <Modal title="" onClose={onClose}
      footer={<button className="btn btn-success btn-full" onClick={onClose}>Continue Booking</button>}>
      <div style={{ textAlign: 'center', padding: '12px 0 8px' }}>
        <div className="success-icon">
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"/>
          </svg>
        </div>
        <div style={{ fontSize: '0.84rem', color: 'var(--text-3)', marginBottom: 6 }}>Seat Secured!</div>
        <div className="success-seat">{booking.seat_code}</div>
        <div style={{ fontSize: '0.78rem', color: 'var(--text-4)', marginBottom: 20 }}>Your seat number</div>
      </div>
      <div className="booking-detail">
        {[
          ['Course',    booking.course_name],
          ['Token',     booking.token_code],
          ['Booked at', new Date(booking.booked_at).toLocaleTimeString()],
        ].map(([label, val]) => (
          <div key={label} className="booking-detail-row">
            <span className="booking-detail-label">{label}</span>
            <span className="booking-detail-value">{val}</span>
          </div>
        ))}
      </div>
    </Modal>
  );
}

/* ── Main Dashboard ─────────────────────────────────────────── */
export default function StudentDashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [bookingCourse, setBookingCourse] = useState(null);
  const [successBooking, setSuccessBooking] = useState(null);
  const [bookingLoading, setBookingLoading] = useState(false);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    api.get('/student/dashboard').then(r => setData(r.data))
      .catch(() => setError('Failed to load dashboard.'))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    if (data?.student?.election_status !== 'ACTIVE') return;
    const iv = setInterval(load, 15000);
    return () => clearInterval(iv);
  }, [data?.student?.election_status, load]);

  const nextToken = data?.tokens?.find(t => t.status === 'UNUSED');

  const confirmBooking = async () => {
    if (!bookingCourse || !nextToken) return;
    setBookingLoading(true); setError('');
    try {
      const { data: res } = await api.post('/student/book', {
        course_id: bookingCourse.course_id,
        election_id: data.student.election_id,
      });
      setBookingCourse(null);
      setSuccessBooking(res.booking);
      load();
    } catch (err) {
      setError(err.response?.data?.message || 'Booking failed. Please try again.');
      setBookingCourse(null);
    } finally { setBookingLoading(false); }
  };

  if (loading) return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <Spinner dark />
      </main>
    </div>
  );

  const { student, tokens = [], courses = [], stats = {} } = data || {};
  const isActive  = student?.election_status === 'ACTIVE';
  const bookedCount = stats.booked || 0;
  const totalTokens = stats.total_tokens || 0;
  const remainingTokens = totalTokens - bookedCount;

  return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content">

        {/* ── Header ── */}
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Hey, {student?.name?.split(' ')[0]} 👋</h1>
            <p className="page-subtitle">
              <span className="code-chip">{student?.full_student_id}</span> &nbsp;
              Section {student?.section} &nbsp;·&nbsp; {student?.email}
            </p>
          </div>
          {student?.election_status && <StatusPill status={student.election_status} />}
        </div>

        {error && <Alert type="error">{error}</Alert>}

        {/* ── No election ── */}
        {!student?.election_id && (
          <div className="card" style={{ textAlign: 'center', padding: '64px 24px' }}>
            <div style={{ fontSize: '3rem', marginBottom: 14 }}>⏳</div>
            <h3 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--text)', marginBottom: 8 }}>Not Linked to an Election</h3>
            <p className="text-muted" style={{ maxWidth: 340, margin: '0 auto' }}>Your account is ready but hasn't been linked to an election yet. Your admin will assign you shortly.</p>
          </div>
        )}

        {/* ── Election status notice ── */}
        {student?.election_id && !isActive && student?.election_status && (
          <Alert type={student.election_status === 'STOPPED' ? 'info' : 'warning'}>
            {student.election_status === 'STOPPED'
              ? '✅ Election has ended. View your final results in My Results.'
              : student.election_status === 'PAUSED'
              ? '⏸ Election is paused. Booking temporarily suspended.'
              : '🕒 Election has not started yet. Check back soon.'}
          </Alert>
        )}

        {/* ── Token Progress Bar ── */}
        {tokens.length > 0 && (
          <div className="card mb-4">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
              <div>
                <div className="card-title">Token Status</div>
                <div style={{ fontSize: '0.82rem', color: 'var(--text-3)', marginTop: 2 }}>
                  {bookedCount} of {totalTokens} tokens used
                  {remainingTokens > 0 && isActive && <span style={{ color: 'var(--accent)', fontWeight: 600 }}> · {remainingTokens} remaining</span>}
                </div>
              </div>
              {isActive && nextToken && (
                <div style={{
                  background: 'linear-gradient(135deg, var(--accent), var(--accent-2))',
                  color: 'white', borderRadius: 8, padding: '6px 12px',
                  fontSize: '0.75rem', fontWeight: 700, fontFamily: 'var(--mono)',
                }}>
                  Next: {nextToken.token_code}
                </div>
              )}
            </div>

            <div className="token-bar">
              {tokens.map(t => (
                <TokenChip key={t.token_id} number={t.token_number}
                  status={t.token_number === nextToken?.token_number && t.status === 'UNUSED' ? 'next' : t.status.toLowerCase()}
                  courseName={t.course_name} />
              ))}
            </div>
            <ProgressBar value={bookedCount} max={totalTokens} green />

            {isActive && remainingTokens === 0 && (
              <div className="alert alert-success" style={{ marginTop: 12, marginBottom: 0 }}>
                🎉 All tokens used! You're done selecting courses.
              </div>
            )}
          </div>
        )}

        {/* ── Course Grid ── */}
        {courses.length > 0 && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div>
                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 800, color: 'var(--text)', letterSpacing: '-0.3px' }}>
                  {isActive ? 'Available Courses' : 'Course Listing'}
                </h2>
                {isActive && nextToken && (
                  <p style={{ fontSize: '0.8rem', color: 'var(--text-3)', marginTop: 2 }}>Click OPT to book with your next token</p>
                )}
              </div>
              <span className="badge badge-grey">{courses.length} courses</span>
            </div>

            <div className="course-grid">
              {courses.map(c => {
                const pct = c.total_seats > 0 ? (c.total_seats - c.available_seats) / c.total_seats : 0;
                const booked = c.is_booked_by_me;
                const myToken = booked ? tokens.find(t => t.course_id === c.course_id) : null;
                const u = urgency(c.available_seats, c.total_seats);
                const canBook = isActive && !booked && nextToken && c.available_seats > 0;

                return (
                  <div key={c.course_id} className={`course-card ${booked ? 'booked' : ''}`}>
                    <div className="course-card-badge">{c.subject_code || 'ELECTIVE'}</div>
                    <div className="course-card-name">{c.course_name}</div>

                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.8rem', marginBottom: 6 }}>
                      <span style={{ color: 'var(--text-3)' }}>{c.available_seats} seats left</span>
                      {c.total_seats > 0 && (
                        <span style={{ color: u.color, fontWeight: 700, fontSize: '0.72rem' }}>{u.label}</span>
                      )}
                    </div>

                    <div className="seat-bar">
                      <div className={`seat-bar-fill ${pct > 0.8 ? 'crit' : pct > 0.5 ? 'warn' : ''}`}
                        style={{ width: `${pct * 100}%` }} />
                    </div>

                    <div className="course-card-actions">
                      <div>
                        {myToken && (
                          <span className="code-chip" style={{ fontSize: '0.72rem' }}>{myToken.token_code}</span>
                        )}
                      </div>
                      {booked ? (
                        <span className="badge badge-green">✓ Booked</span>
                      ) : canBook ? (
                        <button className="btn btn-primary btn-sm"
                          onClick={() => setBookingCourse(c)}
                          style={{ animation: 'none' }}>
                          OPT →
                        </button>
                      ) : !isActive ? (
                        <span className="badge badge-grey">Closed</span>
                      ) : c.available_seats === 0 ? (
                        <span className="badge badge-red">Full</span>
                      ) : (
                        <span className="badge badge-grey">No token</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── Popups ── */}
        {bookingCourse && (
          <BookingPopup
            course={bookingCourse} nextToken={nextToken}
            coursesRequired={student?.final_courses_per_student}
            onConfirm={confirmBooking} onCancel={() => setBookingCourse(null)}
            loading={bookingLoading}
          />
        )}
        {successBooking && (
          <SuccessPopup booking={successBooking} onClose={() => setSuccessBooking(null)} />
        )}
      </main>
    </div>
  );
}
