# UCOS — Universal Course Opting System

> *"Making the word ELECTIVE truly mean Elective."*

A full-stack web application for fair, transparent, individual-preference-driven elective course allocation in educational institutions.

---

## What This Is

UCOS solves the problem of unfair elective selection processes (WhatsApp polls, show-of-hands, Google Forms majority votes) by replacing them with a structured, auditable system where every student's individual preference is recorded and processed fairly.

**Core Algorithm: PWFCFS-MRA**  
Priority-Weighted First-Come-First-Served Multi-Round Allocation — an original algorithm combining ranked-choice preference theory, FCFS queue fairness, and iterative admin-controlled resource scheduling.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React.js 18, React Router v6, Axios |
| Styling | Custom CSS Design System (no framework dependency) |
| Backend | Node.js + Express.js |
| Database | MySQL 8.0 (InnoDB — ACID transactions) |
| Auth | JWT (jsonwebtoken) + bcryptjs + OTP via Nodemailer |
| File Upload | Multer (CSV parsing) |

---

## Project Structure

```
ucos-app/
├── backend/
│   ├── src/
│   │   ├── app.js                    ← Express entry point
│   │   ├── config/
│   │   │   ├── db.js                 ← MySQL connection pool
│   │   │   └── email.js              ← Nodemailer (OTP + results)
│   │   ├── middleware/
│   │   │   └── auth.js               ← JWT verify, adminOnly, studentOnly
│   │   ├── controllers/
│   │   │   ├── authController.js     ← Register, login, OTP verify
│   │   │   ├── adminController.js    ← Students, CSV upload, pending
│   │   │   ├── courseController.js   ← Course CRUD
│   │   │   ├── electionController.js ← Create, init, start, pause, stop
│   │   │   ├── studentController.js  ← Dashboard, ATOMIC seat booking
│   │   │   └── allocationController.js ← PWFCFS-MRA, burst, cascade, export
│   │   └── routes/
│   │       └── index.js              ← All API routes
│   ├── database/
│   │   └── schema.sql                ← Complete DB schema (10 tables)
│   ├── .env                          ← Config (copy and fill)
│   └── package.json
│
└── frontend/
    ├── public/
    │   └── index.html
    └── src/
        ├── App.js                    ← Router + protected routes
        ├── index.js                  ← React entry point
        ├── index.css                 ← Full design system
        ├── context/
        │   └── AuthContext.js        ← Global auth state
        ├── services/
        │   └── api.js                ← Axios + JWT interceptor
        ├── components/ui/
        │   ├── index.js              ← Spinner, Badge, Modal, StatCard...
        │   └── Sidebar.js            ← Admin + Student sidebars
        └── pages/
            ├── auth/
            │   ├── AdminLogin.js
            │   ├── StudentLogin.js
            │   ├── Register.js       ← AdminRegister + VerifyOTP
            │   └── StudentRegister.js
            ├── admin/
            │   ├── Dashboard.js      ← Overview + quick actions
            │   ├── Students.js       ← CSV upload + student table
            │   ├── Pending.js        ← Approve/reject self-registrations
            │   ├── Courses.js        ← Course CRUD
            │   ├── ElectionControl.js ← Create, init, START/PAUSE/STOP
            │   └── AllocationPanel.js ← PWFCFS-MRA round management
            └── student/
                ├── Dashboard.js      ← Course cards + OPT button + popups
                ├── Bookings.js       ← Token activity table
                └── Results.js        ← Final confirmed allocation
```

---

## Setup & Installation

### Prerequisites
- Node.js v16+
- MySQL 8.0+
- npm or yarn

---

### Step 1 — Database

```sql
-- In MySQL shell:
source /path/to/ucos-app/backend/database/schema.sql
```

Or manually:
```bash
mysql -u root -p < backend/database/schema.sql
```

---

### Step 2 — Backend Setup

```bash
cd ucos-app/backend
npm install
```

Copy and edit `.env`:
```env
# Database
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=ucos_db

# JWT
JWT_SECRET=change_this_to_a_long_random_string_in_production

# Server
PORT=3001
NODE_ENV=development

# Email (Gmail with App Password)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your@gmail.com
SMTP_PASS=your_16_char_app_password
EMAIL_FROM=UCOS System <your@gmail.com>

# Frontend URL
FRONTEND_URL=http://localhost:3000
```

Start backend:
```bash
npm run dev     # development (nodemon)
npm start       # production
```

Backend runs on: `http://localhost:3001`  
Health check: `http://localhost:3001/health`

---

### Step 3 — Frontend Setup

```bash
cd ucos-app/frontend
npm install
npm start
```

Frontend runs on: `http://localhost:3000`

> The `"proxy": "http://localhost:3001"` in `package.json` routes all `/api/*` calls automatically.

---

## Usage Walkthrough

### Admin Flow

1. **Register** → `/admin/register` → fill form → verify OTP → get Admin ID (e.g. `ADM-2026-001`)
2. **Login** → `/admin/login`
3. **Create Election** → Election Control → fill parameters
4. **Add Courses** → Courses page → create 5 courses (ML, AI, IoT, AppDev, SoftDev)
5. **Upload Students** → Students page → upload CSV → 126 students created with tokens
6. **Initialise** → Election Control → click "Initialise Seats & Tokens" → 630 seats + 630 tokens generated
7. **Start Election** → Click START → students can now book
8. **Stop Election** → Click STOP → non-participants auto-assigned
9. **Run Allocation** → Allocation Panel → Round 1 → confirm/burst courses → cascade → verify
10. **Export** → Download CSV → Send emails to students

### Student Flow

1. **Login** → `/login` → enter email, password, Admin ID
2. **Dashboard** → See 5 course cards with live seat counts + token bar
3. **Select Course** → Click OPT → confirmation popup → confirm
4. **Success** → See seat number assigned (e.g. S-042), token marked used
5. **Repeat** for all 5 courses (or as many as required)
6. **Results** → After allocation → My Results page → see final confirmed courses

---

## CSV Upload Format

```csv
serial_no,register_number,name,email,password,section
1,2301107031,Harikrishna,hari@college.edu,pass123,A
2,2301107032,Bharanidharan,bhar@college.edu,pass456,A
3,2301107033,Priya,priya@college.edu,pass789,B
```

- `password` column is optional — defaults to `ucos@123`
- `section` must be A, B, C, D, or E
- Duplicates (same email or register number) are automatically skipped

---

## API Reference

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/admin/register` | Admin registration |
| POST | `/api/auth/admin/login` | Admin login → JWT |
| POST | `/api/auth/student/login` | Student login → JWT |
| POST | `/api/auth/student/register` | Student self-registration |
| POST | `/api/auth/verify-otp` | Verify email OTP |

### Admin
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/admin/students/upload` | Upload students CSV |
| GET | `/api/admin/students` | List students |
| GET | `/api/admin/pending` | Pending registrations |
| POST | `/api/admin/pending/:id` | Approve / reject |

### Courses
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/courses` | Create course |
| GET | `/api/courses?election_id=X` | List courses |
| PUT | `/api/courses/:id` | Update course |
| DELETE | `/api/courses/:id` | Delete course |

### Elections
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/elections` | Create election |
| GET | `/api/elections/:id/status` | Live stats |
| POST | `/api/elections/:id/init` | Generate seats + tokens |
| POST | `/api/elections/:id/start` | Start election |
| POST | `/api/elections/:id/pause` | Pause |
| POST | `/api/elections/:id/resume` | Resume |
| POST | `/api/elections/:id/stop` | Stop + auto-assign |

### Student
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/student/dashboard` | Tokens + courses + stats |
| POST | `/api/student/book` | **ATOMIC** FCFS seat booking |
| GET | `/api/student/results` | Final confirmed courses |

### Allocation (PWFCFS-MRA)
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/allocation/:id/pool` | Round pool distribution |
| POST | `/api/allocation/confirm` | Confirm course at capacity |
| POST | `/api/allocation/burst` | Burst course + cascade |
| GET | `/api/allocation/:id/verify` | Final verification |
| GET | `/api/allocation/:id/export` | Download CSV |
| POST | `/api/allocation/:id/email` | Email all students |

---

## Key Design Decisions

### Why MySQL over MongoDB?
The FCFS seat booking requires **ACID transactions** with **row-level locking** (`SELECT ... FOR UPDATE`). MongoDB's document model cannot guarantee this atomicity without significant complexity. InnoDB gives us this for free.

### Why custom CSS over Tailwind/Bootstrap?
Full control over the design system. The admin and student interfaces have distinct visual identities (navy/blue for admin, dark green for student). A custom design system makes this cleaner without utility class overhead.

### Why no CGPA-based priority?
UCOS uses **time of action** (seat number) as the only tiebreaker. This is intentional — CGPA priority would create a different kind of unfairness (rewarding past performance rather than current preference). FCFS is objective, auditable, and cannot be gamed.

---

## Environment Notes

- **Email OTP**: If SMTP is not configured, the system still works — OTP is logged to console in development mode. You can manually verify accounts via direct database update if needed.
- **Rate limiting**: Booking endpoint is limited to 20 requests/minute per IP to prevent abuse.
- **Concurrent bookings**: Handled by MySQL `SELECT ... FOR UPDATE` row locks. No race conditions possible.

---

## Version

- v1.0 — February 2026
- Algorithm: PWFCFS-MRA (original)
- Author: Student Author — CSE, 6th Semester
