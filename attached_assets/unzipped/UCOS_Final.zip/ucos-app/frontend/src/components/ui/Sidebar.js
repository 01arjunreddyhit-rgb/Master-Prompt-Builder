import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const Icon = ({ name }) => {
  const icons = {
    dashboard:  <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></>,
    students:   <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    courses:    <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></>,
    election:   <><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></>,
    allocation: <><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></>,
    results:    <><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></>,
    logout:     <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></>,
    pending:    <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>,
    home:       <><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
    profile:    <><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></>,
  };
  return (
    <svg className="nav-icon" viewBox="0 0 24 24" fill="none"
         stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {icons[name]}
    </svg>
  );
};

export const AdminSidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const navItems = [
    { group: 'Overview', items: [
      { label: 'Dashboard', icon: 'dashboard', path: '/admin' },
    ]},
    { group: 'Setup', items: [
      { label: 'Students',  icon: 'students',  path: '/admin/students' },
      { label: 'Pending',   icon: 'pending',   path: '/admin/pending' },
      { label: 'Courses',   icon: 'courses',   path: '/admin/courses' },
    ]},
    { group: 'Election', items: [
      { label: 'Control Panel', icon: 'election',   path: '/admin/election' },
      { label: 'Allocation',    icon: 'allocation', path: '/admin/allocation' },
    ]},
    { group: 'Account', items: [
      { label: 'My Profile',    icon: 'profile',  path: '/admin/profile' },
    ]},
  ];

  return (
    <aside className="sidebar">
      <div className="sidebar-logo">
        <div className="logo-text">UCOS</div>
        <div className="logo-sub">Admin Panel</div>
      </div>
      <nav className="sidebar-nav">
        {navItems.map(({ group, items }) => (
          <div key={group}>
            <div className="nav-section-label">{group}</div>
            {items.map(item => (
              <button
                key={item.path}
                className={`nav-item ${pathname === item.path ? 'active' : ''}`}
                onClick={() => navigate(item.path)}
              >
                <Icon name={item.icon} />
                {item.label}
              </button>
            ))}
          </div>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="sidebar-user">
          <strong>{user?.admin_name || user?.name}</strong>
          {user?.college_name && <div style={{ fontSize: '0.72rem', marginBottom: 8 }}>{user.college_name}</div>}
          <span className="code-chip" style={{ fontSize: '0.7rem' }}>{user?.admin_id}</span>
        </div>
        <button className="nav-item" style={{ marginTop: 10, color: '#E74C3C' }} onClick={logout}>
          <Icon name="logout" /> Logout
        </button>
      </div>
    </aside>
  );
};

export const StudentSidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  const navItems = [
    { label: 'Dashboard',    icon: 'home',      path: '/student' },
    { label: 'My Bookings',  icon: 'courses',   path: '/student/bookings' },
    { label: 'My Results',   icon: 'results',   path: '/student/results' },
    { label: 'My Profile',   icon: 'profile',   path: '/student/profile' },
  ];

  return (
    <aside className="sidebar" style={{ background: 'var(--dkgreen)' }}>
      <div className="sidebar-logo">
        <div className="logo-text">UCOS</div>
        <div className="logo-sub">Student Portal</div>
      </div>
      <nav className="sidebar-nav">
        <div className="nav-section-label">Menu</div>
        {navItems.map(item => (
          <button
            key={item.path}
            className={`nav-item ${pathname === item.path ? 'active' : ''}`}
            onClick={() => navigate(item.path)}
          >
            <Icon name={item.icon} />
            {item.label}
          </button>
        ))}
      </nav>
      <div className="sidebar-footer">
        <div className="sidebar-user">
          <strong>{user?.name}</strong>
          <div>Sec {user?.section} · {user?.full_student_id}</div>
          <div style={{ marginTop: 4, fontSize: '0.7rem' }}>{user?.email}</div>
        </div>
        <button className="nav-item" style={{ marginTop: 10, color: '#E74C3C' }} onClick={logout}>
          <Icon name="logout" /> Logout
        </button>
      </div>
    </aside>
  );
};
