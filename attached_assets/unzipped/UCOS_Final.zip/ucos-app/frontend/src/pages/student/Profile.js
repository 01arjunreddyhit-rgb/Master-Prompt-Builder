import React, { useState } from 'react';
import { StudentSidebar } from '../../components/ui/Sidebar';
import { Alert, Spinner } from '../../components/ui/index';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

export default function StudentProfile() {
  const { user } = useAuth();
  const [pwForm, setPwForm] = useState({ current_password: '', new_password: '', confirm: '' });
  const [pwMsg, setPwMsg] = useState(null);
  const [saving, setSaving] = useState(false);
  const set = k => e => setPwForm(f => ({ ...f, [k]: e.target.value }));

  const handleChangePw = async (e) => {
    e.preventDefault();
    setPwMsg(null);
    if (pwForm.new_password !== pwForm.confirm) {
      return setPwMsg({ type: 'error', text: 'New passwords do not match.' });
    }
    if (pwForm.new_password.length < 6) {
      return setPwMsg({ type: 'error', text: 'New password must be at least 6 characters.' });
    }
    setSaving(true);
    try {
      const { data } = await api.put('/student/password', {
        current_password: pwForm.current_password,
        new_password: pwForm.new_password,
      });
      if (data.success) {
        setPwMsg({ type: 'success', text: 'Password changed successfully.' });
        setPwForm({ current_password: '', new_password: '', confirm: '' });
      }
    } catch (err) {
      setPwMsg({ type: 'error', text: err.response?.data?.message || 'Password change failed.' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content">
        <div className="page-header">
          <h1 className="page-title">My Profile</h1>
          <p className="page-subtitle">Your account information</p>
        </div>

        {/* Student info card */}
        <div className="card mb-4">
          <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 20 }}>
            <div style={{
              width: 60, height: 60, borderRadius: '50%',
              background: 'var(--dkgreen)', color: 'white',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1.5rem', fontWeight: 800, flexShrink: 0,
            }}>
              {(user?.name || 'S')[0].toUpperCase()}
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: '1.1rem', color: 'var(--navy)' }}>{user?.name}</div>
              <div style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>{user?.email}</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px,1fr))', gap: 12 }}>
            {[
              ['Student ID',    user?.full_student_id],
              ['Register No.',  user?.register_number],
              ['Section',       `Section ${user?.section}`],
              ['Admin ID',      user?.admin_id],
            ].map(([label, val]) => (
              <div key={label} style={{ background: 'var(--lgrey)', borderRadius: 8, padding: '10px 14px' }}>
                <div className="stat-label">{label}</div>
                <div style={{ fontWeight: 600, marginTop: 3, fontFamily: 'var(--mono)', fontSize: '0.88rem' }}>{val}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Change password */}
        <div className="card" style={{ maxWidth: 440 }}>
          <div className="card-header"><span className="card-title">Change Password</span></div>
          {pwMsg && <Alert type={pwMsg.type}>{pwMsg.text}</Alert>}
          <form onSubmit={handleChangePw}>
            <div className="form-group">
              <label className="form-label">Current Password</label>
              <input className="form-input" type="password" placeholder="••••••••"
                value={pwForm.current_password} onChange={set('current_password')} required />
            </div>
            <div className="form-group">
              <label className="form-label">New Password</label>
              <input className="form-input" type="password" placeholder="Min 6 characters"
                value={pwForm.new_password} onChange={set('new_password')} required />
            </div>
            <div className="form-group">
              <label className="form-label">Confirm New Password</label>
              <input className="form-input" type="password" placeholder="Repeat new password"
                value={pwForm.confirm} onChange={set('confirm')} required />
            </div>
            <button className="btn btn-success btn-full" type="submit" disabled={saving}>
              {saving ? <Spinner /> : 'Change Password'}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
