import React, { useState, useEffect } from 'react';
import { StudentSidebar } from '../../components/ui/Sidebar';
import { Badge, Spinner, EmptyState, TokenChip } from '../../components/ui/index';
import api from '../../services/api';

export default function StudentBookings() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/student/dashboard').then(r => setData(r.data))
      .catch(() => {}).finally(() => setLoading(false));
  }, []);

  const tokens = data?.tokens || [];
  const used = tokens.filter(t => t.status !== 'UNUSED');

  return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content">
        <div className="page-header">
          <h1 className="page-title">My Bookings</h1>
          <p className="page-subtitle">{used.length} of {tokens.length} tokens used</p>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>
        ) : used.length === 0 ? (
          <EmptyState icon="🎫" title="No bookings yet"
            message="Go to Dashboard and start selecting your courses." />
        ) : (
          <div className="card">
            <div className="card-header"><span className="card-title">Token Activity</span></div>

            {/* Token visual row */}
            <div className="token-bar mb-6">
              {tokens.map(t => (
                <TokenChip key={t.token_id} number={t.token_number}
                  status={t.status} courseName={t.course_name} />
              ))}
            </div>

            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Token</th><th>Course</th><th>Seat</th><th>Status</th><th>Booked At</th></tr>
                </thead>
                <tbody>
                  {tokens.map(t => (
                    <tr key={t.token_id}>
                      <td><span className="code-chip">{t.token_code}</span></td>
                      <td>{t.course_name || <span className="text-muted">—</span>}</td>
                      <td>{t.seat_code ? <span className="code-chip">{t.seat_code}</span> : '—'}</td>
                      <td>
                        <Badge variant={
                          t.status === 'CONFIRMED' ? 'green' :
                          t.status === 'BOOKED'    ? 'blue' :
                          t.status === 'BURST'     ? 'red' :
                          t.status === 'AUTO'      ? 'purple' : 'grey'
                        }>{t.status}</Badge>
                      </td>
                      <td className="text-sm text-muted">
                        {t.timestamp_booked ? new Date(t.timestamp_booked).toLocaleString() : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
