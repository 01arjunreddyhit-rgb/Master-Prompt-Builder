import React, { useState, useEffect } from 'react';
import { StudentSidebar } from '../../components/ui/Sidebar';
import { Badge, Spinner, EmptyState } from '../../components/ui/index';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

export default function StudentResults() {
  const { user } = useAuth();
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/student/results').then(r => setResults(r.data.data || []))
      .catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <div className="app-shell">
      <StudentSidebar />
      <main className="main-content">
        <div className="page-header">
          <h1 className="page-title">My Results</h1>
          <p className="page-subtitle">Final confirmed course allocation</p>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>
        ) : results.length === 0 ? (
          <EmptyState icon="📊" title="No results yet"
            message="Your results will appear here after the admin completes allocation." />
        ) : (
          <>
            <div className="alert alert-success mb-4">
              ✓ Your course allocation is finalised. {results.length} course{results.length !== 1 ? 's' : ''} confirmed.
            </div>

            {/* Summary cards */}
            <div className="course-grid mb-6">
              {results.map((r, i) => (
                <div key={i} className="course-card booked">
                  <div className="course-card-badge">Course {i + 1}</div>
                  <div className="course-card-name">{r.course_name}</div>
                  <div className="text-sm text-muted mb-3">{r.subject_code || '—'} · {r.credit_weight} credits</div>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted">Seat</span>
                      <span className="code-chip">{r.seat_code}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted">Token</span>
                      <span className="code-chip">{r.token_code}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted">Method</span>
                      <Badge variant={r.is_auto_assigned ? 'purple' : 'green'}>
                        {r.is_auto_assigned ? 'Auto-assigned' : `Round ${r.round_confirmed}`}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Detailed table */}
            <div className="card">
              <div className="card-header">
                <span className="card-title">Allocation Detail</span>
                <span className="text-sm text-muted">{user?.full_student_id} · Section {user?.section}</span>
              </div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr><th>#</th><th>Course</th><th>Code</th><th>Seat No.</th><th>Token</th><th>Round</th><th>Method</th></tr>
                  </thead>
                  <tbody>
                    {results.map((r, i) => (
                      <tr key={i}>
                        <td><strong>{i + 1}</strong></td>
                        <td><strong>{r.course_name}</strong></td>
                        <td><span className="code-chip">{r.subject_code || '—'}</span></td>
                        <td><span className="code-chip">{r.seat_code}</span></td>
                        <td><span className="code-chip">{r.token_code}</span></td>
                        <td>{r.round_confirmed || 'AUTO'}</td>
                        <td>
                          <Badge variant={r.is_auto_assigned ? 'purple' : 'green'}>
                            {r.is_auto_assigned ? 'Auto' : 'FCFS'}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}
