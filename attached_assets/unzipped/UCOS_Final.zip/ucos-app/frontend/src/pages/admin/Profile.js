import React, { useState } from 'react';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Alert, Spinner } from '../../components/ui/index';
import { useAuth } from '../../context/AuthContext';
import api from '../../services/api';

export default function AdminProfile() {
  const { user, login, token } = useAuth();

  const [infoForm, setInfoForm] = useState({
    admin_name: user?.admin_name || '',
    college_name: user?.college_name || '',
  });
  const [pwForm, setPwForm] = useState({ current_password: '', new_password: '', confirm: '' });
  const [infoMsg, setInfoMsg] = useState(null);
  const [pwMsg, setPwMsg] = useState(null);
  const [savingInfo, setSavingInfo] = useState(false);
  const [savingPw, setSavingPw] = useState(false);

  const setInfo = k => e => setInfoForm(f => ({ ...f, [k]: e.target.value }));
  const setPw = k => e => setPwForm(f => ({ ...f, [k]: e.target.value }));

  const handleSaveInfo = async (e) => {
    e.preventDefault();
    setSavingInfo(true); setInfoMsg(null);
    try {
      const { data } = await api.put('/admin/profile', infoForm);
      if (data.success) {
        // Update stored user
        const updated = { ...user, admin_name: infoForm.admin_name, college_name: infoForm.college_name };
        login(updated, token);
        setInfoMsg({ type: 'success', text: 'Profile updated successfully.' });
      }
    } catch (err) {
      setInfoMsg({ type: 'error', text: err.response?.data?.message || 'Update failed.' });
    } finally {
      setSavingInfo(false);
    }
  };

  const handleChangePw = async (e) => {
    e.preventDefault();
    setPwMsg(null);
    if (pwForm.new_password !== pwForm.confirm) {
      return setPwMsg({ type: 'error', text: 'New passwords do not match.' });
    }
    if (pwForm.new_password.length < 8) {
      return setPwMsg({ type: 'error', text: 'New password must be at least 8 characters.' });
    }
    setSavingPw(true);
    try {
      const { data } = await api.put('/admin/password', {
        current_password: pwForm.current_password,
        new_password: pwForm.new_password,
      });
      if (data.success) {
        setPwMsg({ type: 'success', text: 'Password changed successfully.' });
        setPwForm({ current_password: '', new_password: '', confirm: '' });
      }
    } catch (err) {
      setPwMsg({ type: 'error', text: err.response?.data?.message || 'Password change failed.' });
    } finally {
      setSavingPw(false);
    }
  };

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header">
          <h1 className="page-title">Admin Profile</h1>
          <p className="page-subtitle">Manage your account details</p>
        </div>

        {/* Admin ID info card */}
        <div className="card mb-4" style={{ borderLeft: '4px solid var(--accent)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
            <div style={{
              width: 56, height: 56, borderRadius: '50%',
              background: 'var(--navy)', color: 'white',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '1.4rem', fontWeight: 800, flexShrink: 0,
            }}>
              {(user?.admin_name || 'A')[0].toUpperCase()}
            </div>
            <div>
              <div style={{ fontWeight: 700, fontSize: '1.1rem', color: 'var(--navy)' }}>{user?.admin_name}</div>
              <div style={{ color: 'var(--muted)', fontSize: '0.875rem' }}>{user?.email}</div>
              <div style={{ marginTop: 4 }}>
                <span className="code-chip">{user?.admin_id}</span>
                <span style={{ marginLeft: 8, color: 'var(--muted)', fontSize: '0.78rem' }}>Share this ID with students for login</span>
              </div>
            </div>
          </div>
        </div>

        <div className="grid-2" style={{ gap: 20, alignItems: 'start' }}>
          {/* Update profile info */}
          <div className="card">
            <div className="card-header"><span className="card-title">Profile Information</span></div>
            {infoMsg && <Alert type={infoMsg.type}>{infoMsg.text}</Alert>}
            <form onSubmit={handleSaveInfo}>
              <div className="form-group">
                <label className="form-label">Your Name</label>
                <input className="form-input" value={infoForm.admin_name}
                  onChange={setInfo('admin_name')} required />
              </div>
              <div className="form-group">
                <label className="form-label">Institution Name</label>
                <input className="form-input" value={infoForm.college_name}
                  onChange={setInfo('college_name')} required />
              </div>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input className="form-input" value={user?.email} disabled
                  style={{ opacity: 0.6, cursor: 'not-allowed' }} />
                <div className="form-hint">Email cannot be changed after registration.</div>
              </div>
              <button className="btn btn-primary btn-full" type="submit" disabled={savingInfo}>
                {savingInfo ? <Spinner /> : 'Save Changes'}
              </button>
            </form>
          </div>

          {/* Change password */}
          <div className="card">
            <div className="card-header"><span className="card-title">Change Password</span></div>
            {pwMsg && <Alert type={pwMsg.type}>{pwMsg.text}</Alert>}
            <form onSubmit={handleChangePw}>
              <div className="form-group">
                <label className="form-label">Current Password</label>
                <input className="form-input" type="password" placeholder="••••••••"
                  value={pwForm.current_password} onChange={setPw('current_password')} required />
              </div>
              <div className="form-group">
                <label className="form-label">New Password</label>
                <input className="form-input" type="password" placeholder="Min 8 characters"
                  value={pwForm.new_password} onChange={setPw('new_password')} required />
              </div>
              <div className="form-group">
                <label className="form-label">Confirm New Password</label>
                <input className="form-input" type="password" placeholder="Repeat new password"
                  value={pwForm.confirm} onChange={setPw('confirm')} required />
              </div>
              <button className="btn btn-warning btn-full" type="submit" disabled={savingPw}>
                {savingPw ? <Spinner /> : 'Change Password'}
              </button>
            </form>
          </div>
        </div>

        {/* Admin ID share card */}
        <div className="card mt-4" style={{ background: 'var(--navy)', border: 'none' }}>
          <div style={{ color: 'white' }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>📢 Share Your Admin ID with Students</div>
            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.875rem', marginBottom: 12 }}>
              Students need this ID when logging in or registering. Without it, they cannot access your election.
            </p>
            <div style={{
              background: 'rgba(255,255,255,0.1)', borderRadius: 8, padding: '12px 16px',
              fontFamily: 'var(--mono)', fontSize: '1.4rem', fontWeight: 700,
              letterSpacing: '4px', textAlign: 'center',
            }}>
              {user?.admin_id}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
