import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { StatCard, StatusPill, Spinner, EmptyState, Badge } from '../../components/ui/index';
import api from '../../services/api';

export default function AdminDashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [elections, setElections] = useState([]);
  const [studentCount, setStudentCount] = useState(null);
  const [pendingCount, setPendingCount] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    Promise.all([
      api.get('/elections'),
      api.get('/admin/students'),
      api.get('/admin/pending'),
    ]).then(([elecRes, studRes, pendRes]) => {
      setElections(elecRes.data.data || []);
      setStudentCount(studRes.data.total || 0);
      const pending = (pendRes.data.data || []).filter(p => p.status === 'PENDING');
      setPendingCount(pending.length);
    }).catch(() => {}).finally(() => setLoading(false));
  }, []);

  useEffect(() => { load(); }, [load]);

  const current = elections.find(e => ['NOT_STARTED','ACTIVE','PAUSED'].includes(e.status));
  const past    = elections.filter(e => e.status === 'STOPPED');

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">

        {/* Header */}
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Welcome back, {user?.admin_name?.split(' ')[0]} 👋</h1>
            <p className="page-subtitle">{user?.college_name} · Admin ID: {user?.admin_id}</p>
          </div>
          {current && <StatusPill status={current.status} />}
        </div>

        {/* Top stats */}
        <div className="stat-grid">
          <StatCard label="Total Students" value={studentCount ?? '—'} color="green"
            sub="All time" />
          <StatCard label="Pending Approvals" value={pendingCount ?? '—'} color="orange"
            sub={pendingCount > 0 ? 'Needs review' : 'All clear'} />
          <StatCard label="Total Elections" value={elections.length} color=""
            sub="All time" />
          <StatCard label="Current Status"
            value={current ? <StatusPill status={current.status} /> : <span className="text-muted">—</span>}
            sub={current ? current.election_name : 'No active election'} />
        </div>

        {/* Current election */}
        <div className="card mb-4">
          <div className="card-header">
            <span className="card-title">Current Election</span>
            <button className="btn btn-primary btn-sm" onClick={() => navigate('/admin/election')}>
              Manage →
            </button>
          </div>
          {loading ? (
            <div style={{ textAlign: 'center', padding: 40 }}><Spinner dark /></div>
          ) : current ? (
            <>
              <h3 style={{ fontSize: '1.1rem', color: 'var(--navy)', marginBottom: 10 }}>
                {current.election_name}
              </h3>
              <div className="flex gap-2 mb-4" style={{ flexWrap: 'wrap' }}>
                <StatusPill status={current.status} />
                {current.semester_tag && <span className="badge badge-blue">{current.semester_tag}</span>}
                {current.batch_tag    && <span className="badge badge-grey">{current.batch_tag}</span>}
                <span className="badge badge-green">{current.final_courses_per_student} courses / student</span>
              </div>
              <div className="grid-3" style={{ gap: 12 }}>
                {[
                  { label: 'Students',       val: current.student_count ?? 0 },
                  { label: 'Active Courses', val: current.course_count ?? 0 },
                  { label: 'Faculty Count',  val: current.faculty_count ?? 0 },
                ].map(s => (
                  <div key={s.label} style={{
                    background: 'var(--lgrey)', borderRadius: 8, padding: '12px 16px'
                  }}>
                    <div className="stat-label">{s.label}</div>
                    <div style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--navy)' }}>{s.val}</div>
                  </div>
                ))}
              </div>
              {/* Action row based on status */}
              <div className="flex gap-2 mt-4" style={{ flexWrap: 'wrap' }}>
                {current.status === 'NOT_STARTED' && (
                  <button className="btn btn-success" onClick={() => navigate('/admin/election')}>
                    ▶ Start Election
                  </button>
                )}
                {current.status === 'ACTIVE' && (
                  <button className="btn btn-warning" onClick={() => navigate('/admin/election')}>
                    ⏸ Manage / Pause
                  </button>
                )}
                {current.status === 'STOPPED' && (
                  <button className="btn btn-navy" onClick={() => navigate(`/admin/allocation?id=${current.election_id}`)}>
                    📊 Open Allocation Panel
                  </button>
                )}
                <button className="btn btn-ghost btn-sm" onClick={() => navigate('/admin/students')}>
                  View Students
                </button>
                <button className="btn btn-ghost btn-sm" onClick={() => navigate('/admin/courses')}>
                  View Courses
                </button>
              </div>
            </>
          ) : (
            <EmptyState icon="🗳️" title="No active election"
              message="Create your first election to get started with UCOS."
              action={
                <button className="btn btn-primary" onClick={() => navigate('/admin/election')}>
                  Create Election →
                </button>
              }
            />
          )}
        </div>

        {/* Quick actions */}
        <div className="card mb-4">
          <div className="card-header"><span className="card-title">Quick Actions</span></div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px,1fr))', gap: 12 }}>
            {[
              { label: '⬆ Upload Students', path: '/admin/students',  cls: 'btn-primary' },
              { label: '➕ Add Course',      path: '/admin/courses',   cls: 'btn-warning' },
              { label: '🗳 Election Control', path: '/admin/election',  cls: 'btn-success' },
              { label: '📊 Allocation Panel',path: '/admin/allocation',cls: 'btn-navy' },
              { label: '⏳ Pending',         path: '/admin/pending',   cls: 'btn-ghost' },
            ].map(a => (
              <button key={a.path} className={`btn ${a.cls}`}
                onClick={() => navigate(a.path)}>{a.label}</button>
            ))}
          </div>
        </div>

        {/* Past elections */}
        {past.length > 0 && (
          <div className="card">
            <div className="card-header">
              <span className="card-title">Past Elections</span>
              <Badge variant="grey">{past.length}</Badge>
            </div>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr><th>Name</th><th>Semester</th><th>Batch</th><th>Students</th><th>Status</th><th></th></tr>
                </thead>
                <tbody>
                  {past.map(e => (
                    <tr key={e.election_id}>
                      <td><strong>{e.election_name}</strong></td>
                      <td>{e.semester_tag || '—'}</td>
                      <td>{e.batch_tag || '—'}</td>
                      <td>{e.student_count ?? '—'}</td>
                      <td><StatusPill status={e.status} /></td>
                      <td>
                        <button className="btn btn-ghost btn-sm"
                          onClick={() => navigate(`/admin/allocation?id=${e.election_id}`)}>
                          Results →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
