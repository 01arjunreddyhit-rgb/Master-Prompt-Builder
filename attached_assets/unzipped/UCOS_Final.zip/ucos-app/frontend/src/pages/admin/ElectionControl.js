import React, { useState, useEffect, useCallback } from 'react';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { StatusPill, Alert, Spinner, Modal, ProgressBar } from '../../components/ui/index';
import api from '../../services/api';

export default function ElectionControl() {
  const [elections, setElections] = useState([]);
  const [current, setCurrent] = useState(null);
  const [checklist, setChecklist] = useState(null);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const [showStop, setShowStop] = useState(false);
  const [msg, setMsg] = useState(null);
  const [createForm, setCreateForm] = useState({
    election_name: '', semester_tag: '', batch_tag: '',
    final_courses_per_student: 2, faculty_count: 4,
    min_class_size: 45, max_class_size: 75,
  });
  const setF = (k) => (e) => setCreateForm(f => ({ ...f, [k]: e.target.value }));

  const loadElections = useCallback(() => {
    api.get('/elections').then(r => {
      const list = r.data.data || [];
      setElections(list);
      const active = list.find(e => ['NOT_STARTED','ACTIVE','PAUSED'].includes(e.status));
      if (active) setCurrent(active);
    });
  }, []);

  const loadStatus = useCallback((id) => {
    api.get(`/elections/${id}/status`).then(r => setStatus(r.data.data));
    api.get(`/elections/${id}/checklist`).then(r => setChecklist(r.data));
  }, []);

  useEffect(() => { loadElections(); }, [loadElections]);
  useEffect(() => {
    if (current?.election_id) {
      loadStatus(current.election_id);
      const iv = setInterval(() => loadStatus(current.election_id), 10000);
      return () => clearInterval(iv);
    }
  }, [current?.election_id, loadStatus]);

  const action = async (type) => {
    if (!current) return;
    setActionLoading(type); setMsg(null);
    try {
      const eps = { init: 'init', start: 'start', pause: 'pause', resume: 'resume' };
      const { data } = await api.post(`/elections/${current.election_id}/${eps[type]}`);
      setMsg({ type: 'success', text: data.message });
      loadElections();
      loadStatus(current.election_id);
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Action failed.' });
    } finally {
      setActionLoading('');
    }
  };

  const handleStop = async () => {
    setShowStop(false); setActionLoading('stop'); setMsg(null);
    try {
      const { data } = await api.post(`/elections/${current.election_id}/stop`);
      setMsg({ type: 'success', text: data.message });
      loadElections();
      loadStatus(current.election_id);
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Stop failed.' });
    } finally {
      setActionLoading('');
    }
  };

  const handleCreate = async (e) => {
    e.preventDefault(); setLoading(true); setMsg(null);
    try {
      const { data } = await api.post('/elections', createForm);
      setMsg({ type: 'success', text: 'Election created! Now add courses and upload students.' });
      setShowCreate(false);
      loadElections();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Create failed.' });
    } finally {
      setLoading(false);
    }
  };

  const CheckItem = ({ ok, label, count, expected }) => (
    <li>
      <span className={`check-icon ${ok ? 'ok' : 'fail'}`}>{ok ? '✓' : '·'}</span>
      <span style={{ flex: 1 }}>{label}</span>
      <span className="text-sm" style={{ color: ok ? 'var(--dkgreen)' : 'var(--muted)', fontFamily: 'var(--mono)' }}>
        {count}{expected !== undefined ? ` / ${expected}` : ''}
      </span>
    </li>
  );

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Election Control</h1>
            <p className="page-subtitle">Manage the election lifecycle</p>
          </div>
          {!current && (
            <button className="btn btn-primary" onClick={() => setShowCreate(true)}>+ New Election</button>
          )}
        </div>

        {msg && <Alert type={msg.type}>{msg.text}</Alert>}

        {!current ? (
          <div className="card">
            <div style={{ textAlign: 'center', padding: '48px 20px' }}>
              <div style={{ fontSize: '3rem', marginBottom: 16 }}>🗳️</div>
              <h3 style={{ marginBottom: 8, color: 'var(--navy)' }}>No active election</h3>
              <p className="text-muted" style={{ marginBottom: 20 }}>Create an election to start the UCOS process.</p>
              <button className="btn btn-primary btn-lg" onClick={() => setShowCreate(true)}>
                Create Election
              </button>
            </div>
          </div>
        ) : (
          <>
            {/* Election Header */}
            <div className="card mb-4">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h2 style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--navy)' }}>
                    {current.election_name}
                  </h2>
                  <div className="flex gap-2 mt-2" style={{ flexWrap: 'wrap' }}>
                    <StatusPill status={current.status} />
                    {current.semester_tag && <span className="badge badge-blue">{current.semester_tag}</span>}
                    {current.batch_tag && <span className="badge badge-grey">{current.batch_tag}</span>}
                  </div>
                </div>
                <div className="text-sm text-muted" style={{ textAlign: 'right' }}>
                  <div>ID: <span className="code-chip">#{current.election_id}</span></div>
                  <div>Final courses / student: <strong>{current.final_courses_per_student}</strong></div>
                </div>
              </div>

              {/* Live stats */}
              {status && (
                <div className="grid-3" style={{ gap: 12, marginBottom: 16 }}>
                  {[
                    { label: 'Students', val: status.total_students || 0 },
                    { label: 'Active Courses', val: status.active_courses || 0 },
                    { label: 'Total Bookings', val: status.total_bookings || 0 },
                  ].map(s => (
                    <div key={s.label} style={{ background: 'var(--lgrey)', borderRadius: 8, padding: '10px 14px' }}>
                      <div className="stat-label">{s.label}</div>
                      <div style={{ fontSize: '1.5rem', fontWeight: 800 }}>{s.val}</div>
                    </div>
                  ))}
                </div>
              )}

              {/* Booking progress */}
              {status && status.total_students > 0 && (
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Booking Progress</span>
                    <span className="font-bold">{status.students_started || 0} / {status.total_students} students started</span>
                  </div>
                  <ProgressBar value={status.students_started || 0} max={status.total_students} green />
                </div>
              )}
            </div>

            {/* Checklist + Controls side by side */}
            <div className="grid-2 gap-4 mb-4">
              {/* Checklist */}
              <div className="card">
                <div className="card-header"><span className="card-title">Pre-Start Checklist</span></div>
                {checklist ? (
                  <>
                    <ul className="checklist">
                      <CheckItem ok={checklist.checklist.students.ok} label="Students registered" count={checklist.checklist.students.count} />
                      <CheckItem ok={checklist.checklist.courses.ok} label="Courses created" count={checklist.checklist.courses.count} />
                      <CheckItem ok={checklist.checklist.tokens.ok} label="Tokens generated"
                        count={checklist.checklist.tokens.count} expected={checklist.checklist.tokens.expected} />
                      <CheckItem ok={checklist.checklist.seats.ok} label="Seats initialised"
                        count={checklist.checklist.seats.count} expected={checklist.checklist.seats.expected} />
                    </ul>
                    {!checklist.checklist.tokens.ok && checklist.checklist.students.ok && checklist.checklist.courses.ok && (
                      <button className="btn btn-warning btn-full mt-4"
                        onClick={() => action('init')} disabled={actionLoading === 'init'}>
                        {actionLoading === 'init' ? <Spinner /> : '⚙ Initialise Tokens & Seats'}
                      </button>
                    )}
                  </>
                ) : <div style={{ padding: 20, textAlign: 'center' }}><Spinner dark /></div>}
              </div>

              {/* Controls */}
              <div className="card">
                <div className="card-header"><span className="card-title">Election Controls</span></div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {current.status === 'NOT_STARTED' && (
                    <button className="btn btn-success btn-full"
                      onClick={() => action('start')}
                      disabled={!checklist?.allReady || actionLoading === 'start'}>
                      {actionLoading === 'start' ? <Spinner /> : '▶  START ELECTION'}
                    </button>
                  )}
                  {current.status === 'ACTIVE' && (
                    <>
                      <button className="btn btn-warning btn-full"
                        onClick={() => action('pause')} disabled={actionLoading === 'pause'}>
                        {actionLoading === 'pause' ? <Spinner /> : '⏸  PAUSE ELECTION'}
                      </button>
                      <button className="btn btn-danger btn-full"
                        onClick={() => setShowStop(true)} disabled={!!actionLoading}>
                        ⏹  STOP ELECTION
                      </button>
                    </>
                  )}
                  {current.status === 'PAUSED' && (
                    <>
                      <button className="btn btn-success btn-full"
                        onClick={() => action('resume')} disabled={actionLoading === 'resume'}>
                        {actionLoading === 'resume' ? <Spinner /> : '▶  RESUME ELECTION'}
                      </button>
                      <button className="btn btn-danger btn-full"
                        onClick={() => setShowStop(true)} disabled={!!actionLoading}>
                        ⏹  STOP ELECTION
                      </button>
                    </>
                  )}
                  {current.status === 'STOPPED' && (
                    <div className="alert alert-info">
                      Election stopped. Proceed to <strong>Allocation Panel</strong> to run rounds.
                    </div>
                  )}
                </div>

                {!checklist?.allReady && current.status === 'NOT_STARTED' && (
                  <p className="text-xs text-muted mt-4">
                    ⚠ Complete checklist before starting.
                  </p>
                )}
              </div>
            </div>
          </>
        )}

        {/* Create Election Modal */}
        {showCreate && (
          <Modal title="Create New Election" onClose={() => setShowCreate(false)}
            footer={
              <>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowCreate(false)}>Cancel</button>
                <button className="btn btn-primary btn-sm" onClick={handleCreate} disabled={loading}>
                  {loading ? <Spinner /> : 'Create Election'}
                </button>
              </>
            }>
            <form onSubmit={handleCreate}>
              <div className="form-group">
                <label className="form-label">Election Name *</label>
                <input className="form-input" placeholder="6th Semester Elective Allocation 2026"
                  value={createForm.election_name} onChange={setF('election_name')} required />
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Semester Tag</label>
                  <input className="form-input" placeholder="6th Sem" value={createForm.semester_tag} onChange={setF('semester_tag')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Batch Tag</label>
                  <input className="form-input" placeholder="2023–2027" value={createForm.batch_tag} onChange={setF('batch_tag')} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Courses / Student</label>
                  <input className="form-input" type="number" min="1" value={createForm.final_courses_per_student} onChange={setF('final_courses_per_student')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Faculty Count</label>
                  <input className="form-input" type="number" min="1" value={createForm.faculty_count} onChange={setF('faculty_count')} />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label className="form-label">Min Class Size</label>
                  <input className="form-input" type="number" value={createForm.min_class_size} onChange={setF('min_class_size')} />
                </div>
                <div className="form-group">
                  <label className="form-label">Max Class Size</label>
                  <input className="form-input" type="number" value={createForm.max_class_size} onChange={setF('max_class_size')} />
                </div>
              </div>
            </form>
          </Modal>
        )}

        {/* Confirm Stop Modal */}
        {showStop && (
          <Modal title="⏹ Stop Election" onClose={() => setShowStop(false)}
            footer={
              <>
                <button className="btn btn-ghost btn-sm" onClick={() => setShowStop(false)}>Cancel</button>
                <button className="btn btn-danger btn-sm" onClick={handleStop}>
                  {actionLoading === 'stop' ? <Spinner /> : 'Yes, Stop Election'}
                </button>
              </>
            }>
            <div className="alert alert-warning">
              <strong>This action cannot be undone.</strong>
            </div>
            <p>Stopping the election will:</p>
            <ul style={{ marginTop: 8, paddingLeft: 20, lineHeight: 2, fontSize: '0.9rem' }}>
              <li>Close all booking immediately</li>
              <li>Auto-assign remaining courses to non-participants</li>
              <li>Unlock the Allocation Panel</li>
            </ul>
          </Modal>
        )}
      </main>
    </div>
  );
}
