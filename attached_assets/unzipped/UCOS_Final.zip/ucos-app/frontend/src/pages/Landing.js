import React from 'react';
import { useNavigate } from 'react-router-dom';

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #0D1B2A 0%, #1B4F72 60%, #2E86C1 100%)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      padding: 24, textAlign: 'center',
    }}>
      {/* Logo */}
      <div style={{ marginBottom: 40 }}>
        <div style={{
          fontSize: '4rem', fontWeight: 900, color: 'white',
          letterSpacing: '-2px', lineHeight: 1,
        }}>UCOS</div>
        <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: '0.9rem', marginTop: 8, letterSpacing: '2px', textTransform: 'uppercase' }}>
          Universal Course Opting System
        </div>
      </div>

      {/* Tagline */}
      <h1 style={{
        color: 'white', fontSize: 'clamp(1.4rem, 4vw, 2.2rem)',
        fontWeight: 700, maxWidth: 560, lineHeight: 1.4, marginBottom: 12,
      }}>
        Making the word <em style={{ color: '#5DADE2' }}>Elective</em> truly mean Elective.
      </h1>
      <p style={{
        color: 'rgba(255,255,255,0.65)', fontSize: '1rem',
        maxWidth: 480, lineHeight: 1.7, marginBottom: 48,
      }}>
        A fair, transparent, bias-free platform for elective course selection —
        built on individual preference, not group majority.
      </p>

      {/* CTA Buttons */}
      <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 64 }}>
        <button
          className="btn btn-lg"
          style={{ background: 'white', color: 'var(--navy)', fontWeight: 700, minWidth: 180 }}
          onClick={() => navigate('/admin/login')}
        >
          Admin Login
        </button>
        <button
          className="btn btn-lg"
          style={{ background: 'var(--dkgreen)', color: 'white', fontWeight: 700, minWidth: 180 }}
          onClick={() => navigate('/login')}
        >
          Student Login
        </button>
      </div>

      {/* Feature pills */}
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', justifyContent: 'center', marginBottom: 48 }}>
        {[
          '🔒 ACID-safe FCFS Booking',
          '🎫 Token-based Priority',
          '📊 Real-time Allocation',
          '💌 Auto Email Results',
          '📥 CSV Export',
          '⚙ PWFCFS-MRA Algorithm',
        ].map(f => (
          <div key={f} style={{
            background: 'rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.85)',
            padding: '6px 14px', borderRadius: 100, fontSize: '0.8rem', fontWeight: 500,
            border: '1px solid rgba(255,255,255,0.15)',
          }}>{f}</div>
        ))}
      </div>

      {/* How it works strip */}
      <div style={{
        background: 'rgba(255,255,255,0.07)',
        borderRadius: 16, padding: '28px 32px',
        maxWidth: 720, width: '100%',
        border: '1px solid rgba(255,255,255,0.1)',
      }}>
        <h3 style={{ color: 'white', marginBottom: 20, fontSize: '1rem', fontWeight: 600 }}>
          How UCOS Works
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px,1fr))', gap: 16 }}>
          {[
            { step: '1', icon: '🏫', title: 'Admin Sets Up', desc: 'Creates election, adds courses, uploads students' },
            { step: '2', icon: '🎫', title: 'Tokens Issued', desc: 'Each student gets N tokens — one per course slot' },
            { step: '3', icon: '⚡', title: 'Students Opt', desc: 'Click OPT to book seats in real-time (FCFS)' },
            { step: '4', icon: '📊', title: 'Admin Allocates', desc: 'Confirm / burst courses via PWFCFS-MRA rounds' },
            { step: '5', icon: '✅', title: 'Results Published', desc: 'Final seats confirmed, emails sent, CSV exported' },
          ].map(s => (
            <div key={s.step} style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '1.8rem', marginBottom: 6 }}>{s.icon}</div>
              <div style={{ color: 'white', fontWeight: 600, fontSize: '0.85rem', marginBottom: 4 }}>{s.title}</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.75rem', lineHeight: 1.4 }}>{s.desc}</div>
            </div>
          ))}
        </div>
      </div>

      <p style={{ color: 'rgba(255,255,255,0.3)', fontSize: '0.75rem', marginTop: 40 }}>
        UCOS v1.0 · CSE Dept · 2026
      </p>
    </div>
  );
}
