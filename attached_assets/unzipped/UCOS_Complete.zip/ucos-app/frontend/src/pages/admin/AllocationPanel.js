import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { AdminSidebar } from '../../components/ui/Sidebar';
import { Badge, Alert, Spinner, Modal, ProgressBar } from '../../components/ui/index';
import api from '../../services/api';

export default function AllocationPanel() {
  const [sp] = useSearchParams();
  const [elections, setElections] = useState([]);
  const [electionId, setElectionId] = useState(sp.get('id') || '');
  const [pool, setPool] = useState(null);
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState('');
  const [msg, setMsg] = useState(null);
  const [verifyResult, setVerifyResult] = useState(null);
  const [roundNum, setRoundNum] = useState(1);

  // Confirm modal state
  const [confirmModal, setConfirmModal] = useState(null); // {course_id, course_name, max_enrollment, total_tokens}
  const [burstModal, setBurstModal] = useState(null);
  const [capacity, setCapacity] = useState('');

  useEffect(() => {
    api.get('/elections').then(r => {
      const list = r.data.data || [];
      setElections(list);
      if (!electionId) {
        const stopped = list.find(e => e.status === 'STOPPED');
        if (stopped) setElectionId(String(stopped.election_id));
      }
    });
  }, []); // eslint-disable-line

  const loadPool = useCallback(() => {
    if (!electionId) return;
    setLoading(true);
    api.get(`/allocation/${electionId}/pool`)
      .then(r => setPool(r.data))
      .catch(() => setMsg({ type: 'error', text: 'Failed to load allocation pool.' }))
      .finally(() => setLoading(false));
  }, [electionId]);

  useEffect(() => { loadPool(); }, [loadPool]);

  const handleConfirm = async () => {
    setActionLoading('confirm'); setMsg(null);
    try {
      const { data } = await api.post('/allocation/confirm', {
        election_id: parseInt(electionId),
        course_id: confirmModal.course_id,
        capacity: parseInt(capacity),
        round_number: roundNum,
      });
      setMsg({ type: 'success', text: `✓ ${confirmModal.course_name}: ${data.confirmed} confirmed, ${data.burst} cascaded.` });
      setConfirmModal(null);
      loadPool();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Confirm failed.' });
    } finally {
      setActionLoading('');
    }
  };

  const handleBurst = async () => {
    setActionLoading('burst'); setMsg(null);
    try {
      const { data } = await api.post('/allocation/burst', {
        election_id: parseInt(electionId),
        course_id: burstModal.course_id,
        round_number: roundNum,
      });
      setMsg({ type: 'success', text: `Course burst. ${data.burst_count} students cascaded.` });
      setBurstModal(null);
      loadPool();
    } catch (err) {
      setMsg({ type: 'error', text: err.response?.data?.message || 'Burst failed.' });
    } finally {
      setActionLoading('');
    }
  };

  const handleVerify = async () => {
    setActionLoading('verify');
    try {
      const { data } = await api.get(`/allocation/${electionId}/verify`);
      setVerifyResult(data);
    } catch (err) {
      setMsg({ type: 'error', text: 'Verification failed.' });
    } finally {
      setActionLoading('');
    }
  };

  const handleExport = () => {
    const token = localStorage.getItem('ucos_token');
    const base = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
    const url = `${base}/allocation/${electionId}/export`;
    fetch(url, { headers: { Authorization: `Bearer ${token}` } })
      .then(r => r.blob())
      .then(blob => {
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `ucos_allocation_${electionId}.csv`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      })
      .catch(() => setMsg({ type: 'error', text: 'Export failed. Check connection.' }));
  };

  const handleEmail = async () => {
    if (!window.confirm('Send result emails to all students?')) return;
    setActionLoading('email');
    try {
      const { data } = await api.post(`/allocation/${electionId}/email`);
      setMsg({ type: 'success', text: data.message });
    } catch (err) {
      setMsg({ type: 'error', text: 'Email send failed.' });
    } finally {
      setActionLoading('');
    }
  };

  const demandPct = (c) => {
    const max = c.max_enrollment || 1;
    return Math.min(100, Math.round(((c.total_tokens || 0) / max) * 100));
  };

  return (
    <div className="app-shell">
      <AdminSidebar />
      <main className="main-content">
        <div className="page-header flex justify-between items-center">
          <div>
            <h1 className="page-title">Allocation Panel</h1>
            <p className="page-subtitle">PWFCFS-MRA — Multi-round allocation</p>
          </div>
          <div className="flex gap-2 items-center">
            <select className="form-select" value={electionId} onChange={e => setElectionId(e.target.value)} style={{ width: 220 }}>
              <option value="">Select Election</option>
              {elections.map(e => <option key={e.election_id} value={e.election_id}>{e.election_name}</option>)}
            </select>
            <span className="text-sm text-muted">Round:</span>
            <input className="form-input" type="number" min="1" value={roundNum}
              onChange={e => setRoundNum(parseInt(e.target.value))} style={{ width: 70 }} />
            <button className="btn btn-navy btn-sm" onClick={loadPool} disabled={loading}>
              {loading ? <Spinner /> : '↻ Refresh'}
            </button>
          </div>
        </div>

        {msg && <Alert type={msg.type}>{msg.text}</Alert>}

        {!electionId ? (
          <div className="alert alert-warning">Select a stopped election to run allocation.</div>
        ) : loading ? (
          <div style={{ textAlign: 'center', padding: 60 }}><Spinner dark /></div>
        ) : pool ? (
          <>
            {/* Stats bar */}
            {pool.stats && (
              <div className="stat-grid mb-4">
                <div className="stat-card"><div className="stat-label">Total Tokens</div><div className="stat-value">{pool.stats.total_students}</div></div>
                <div className="stat-card green"><div className="stat-label">Confirmed</div><div className="stat-value">{pool.stats.confirmed}</div></div>
                <div className="stat-card orange"><div className="stat-label">Booked</div><div className="stat-value">{pool.stats.booked}</div></div>
                <div className="stat-card red"><div className="stat-label">Burst</div><div className="stat-value">{pool.stats.burst}</div></div>
                <div className="stat-card purple"><div className="stat-label">Auto-Assigned</div><div className="stat-value">{pool.stats.auto_assigned}</div></div>
                <div className="stat-card"><div className="stat-label">Pending Students</div><div className="stat-value">{pool.students_pending}</div></div>
              </div>
            )}

            {/* Round pool table */}
            <div className="card mb-4">
              <div className="card-header">
                <span className="card-title">Round {roundNum} — Demand Distribution (T1 + T2 pool)</span>
                <span className="text-sm text-muted">{pool.pool?.length || 0} courses</span>
              </div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr>
                      <th>Course</th><th>Code</th><th>T1</th><th>T2</th><th>T3</th><th>Total</th>
                      <th>Min/Max</th><th>Demand %</th><th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(pool.pool || []).map(c => (
                      <tr key={c.course_id}
                        className={c.is_burst ? 'alloc-row-burst' : (c.total_tokens >= c.min_enrollment ? 'alloc-row-confirmed' : '')}>
                        <td><strong>{c.course_name}</strong></td>
                        <td><span className="code-chip">{c.subject_code || '—'}</span></td>
                        <td>{c.t1_count || 0}</td>
                        <td>{c.t2_count || 0}</td>
                        <td>{c.t3_count || 0}</td>
                        <td><strong>{c.total_tokens || 0}</strong></td>
                        <td className="text-sm text-muted">{c.min_enrollment} / {c.max_enrollment}</td>
                        <td style={{ width: 100 }}>
                          <ProgressBar value={c.total_tokens || 0} max={c.max_enrollment} green={c.total_tokens >= c.min_enrollment} />
                          <div className="text-xs text-muted">{demandPct(c)}%</div>
                        </td>
                        <td>
                          {c.is_burst ? (
                            <Badge variant="red">Burst</Badge>
                          ) : (
                            <div className="flex gap-2">
                              <button className="btn btn-success btn-sm"
                                onClick={() => { setConfirmModal(c); setCapacity(String(Math.min(c.max_enrollment, c.total_tokens || 0))); }}>
                                Confirm
                              </button>
                              <button className="btn btn-danger btn-sm"
                                onClick={() => setBurstModal(c)}>
                                Burst
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Verify + Export row */}
            <div className="card">
              <div className="card-header"><span className="card-title">Finalise</span></div>
              <div className="flex gap-3" style={{ flexWrap: 'wrap' }}>
                <button className="btn btn-navy" onClick={handleVerify} disabled={actionLoading === 'verify'}>
                  {actionLoading === 'verify' ? <Spinner /> : '✓ Run Final Verification'}
                </button>
                <button className="btn btn-success" onClick={handleExport} disabled={actionLoading === 'export'}>
                  ⬇ Download CSV
                </button>
                <button className="btn btn-primary" onClick={handleEmail} disabled={actionLoading === 'email'}>
                  {actionLoading === 'email' ? <Spinner /> : '✉ Email All Students'}
                </button>
              </div>

              {verifyResult && (
                <div className={`alert mt-4 ${verifyResult.verified ? 'alert-success' : 'alert-error'}`}>
                  {verifyResult.verified ? (
                    <>✓ Allocation verified! {verifyResult.total_students} students × {verifyResult.required_per_student} courses = {verifyResult.total_confirmed} confirmed assignments.</>
                  ) : (
                    <>⚠ Verification failed. {verifyResult.flagged_students?.length} students have incomplete allocation.</>
                  )}
                </div>
              )}
            </div>
          </>
        ) : null}

        {/* Confirm Modal */}
        {confirmModal && (
          <Modal title={`Confirm: ${confirmModal.course_name}`} onClose={() => setConfirmModal(null)}
            footer={
              <>
                <button className="btn btn-ghost btn-sm" onClick={() => setConfirmModal(null)}>Cancel</button>
                <button className="btn btn-success btn-sm" onClick={handleConfirm} disabled={actionLoading === 'confirm'}>
                  {actionLoading === 'confirm' ? <Spinner /> : 'Confirm Course'}
                </button>
              </>
            }>
            <div className="alert alert-info">
              Total tokens in pool: <strong>{confirmModal.total_tokens || 0}</strong>
              {' '}· Min: {confirmModal.min_enrollment} · Max: {confirmModal.max_enrollment}
            </div>
            <div className="form-group mt-4">
              <label className="form-label">Confirm at capacity (seats to confirm)</label>
              <input className="form-input" type="number" value={capacity}
                onChange={e => setCapacity(e.target.value)}
                min="1" max={confirmModal.total_tokens || 999} />
              <div className="form-hint">
                Top-{capacity || 0} students by seat number (FCFS) will be CONFIRMED.
                Remaining {Math.max(0, (confirmModal.total_tokens || 0) - parseInt(capacity || 0))} will be cascaded.
              </div>
            </div>
          </Modal>
        )}

        {/* Burst Modal */}
        {burstModal && (
          <Modal title={`Burst: ${burstModal.course_name}`} onClose={() => setBurstModal(null)}
            footer={
              <>
                <button className="btn btn-ghost btn-sm" onClick={() => setBurstModal(null)}>Cancel</button>
                <button className="btn btn-danger btn-sm" onClick={handleBurst} disabled={actionLoading === 'burst'}>
                  {actionLoading === 'burst' ? <Spinner /> : 'Burst Course'}
                </button>
              </>
            }>
            <div className="alert alert-error">
              <strong>This cannot be undone.</strong>
            </div>
            <p className="text-sm">
              Bursting <strong>{burstModal.course_name}</strong> will:
            </p>
            <ul style={{ marginTop: 8, paddingLeft: 20, lineHeight: 2, fontSize: '0.875rem' }}>
              <li>Deactivate all {burstModal.total_seats} seats for this course</li>
              <li>Mark all {burstModal.total_tokens || 0} booked tokens as BURST</li>
              <li>Cascade each student individually to their next token</li>
            </ul>
          </Modal>
        )}
      </main>
    </div>
  );
}
